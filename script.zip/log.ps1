# Funktion zum Konvertieren von farbigem Text in HTML
function ConvertTo-HTMLColorText {
    param (
        [string]$Text,
        [string]$ForegroundColor
    )

    $htmlText = "<font color='$ForegroundColor'>$Text</font>"
    return $htmlText
}

# Funktion zum Schreiben von farbigem Text in eine HTML-Datei
function Write-Log {
    param (
        [string]$Text,
        [string]$FilePath,
        [string]$ForegroundColor
    )

    $formattedText = ConvertTo-HTMLColorText -Text $Text -ForegroundColor $ForegroundColor
    $formattedText | Out-File -Append -FilePath $FilePath
}

# Verwendung der Funktion
$LogFile = "C:\Logdatei.html"



