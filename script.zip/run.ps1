function Run {
# Path to Update 
. "C:\APA\script\update_7zip.ps1"
#. ".\update_teamViewer.ps1"
#. ".\update_vlc.ps1"
#. ".\update_xChange.ps1"
#. ".\update_pdf24.ps1"
#. ".\update_Java.ps1"
#. ".\update_paintNet.ps1"
#. ".\update_Firefox.ps1"

#. ".\update_geoGebra_classic.ps1"
#. ".\update_Inkscape.ps1"
#. ".\update_filius.ps1"
#. ".\update_audacity.ps1"
#. ".\update_gimp.ps1"

# Start Update 
Update_7zip
#Update_teamViewer
#Update_VLC
#Update_XChange
#Update_PDF24
#Update_Java
#Update_PaintNet
#Update_Firefox

#Update_geoGebra_classic
#Update_Inkscape
#Update_filius
#Update_audacity
#Update_Gimp
}