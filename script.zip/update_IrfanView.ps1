﻿function update_IrfanView {
$PName = "IrfanView"
Write-Host 
# Überprüft ob IrfanView Installiert ist
if (Test-Path "C:\Program Files\IrfanView\i_view64.exe") {
    # Überprüft die Installierte Version von IrfanView
    $LocalVersion = (Get-Item "C:\Program Files\IrfanView\i_view64.exe" ).VersionInfo.ProductVersion 

	$LocalVersion = $LocalVersion.Split('.')
    $LocalVersion = $LocalVersion[0] + "." + $LocalVersion[1]


    Write-Host "$PName ist in Version $localVersion installiert"

    # Überprüft die aktuellste Version von 
    $html = Invoke-WebRequest -Uri "https://www.fosshub.com/IrfanView-DE.html" | Select-Object -ExpandProperty Content
    
    $regex = [regex]'(?<=<dd itemprop="softwareVersion">)\d+\.\d+(?=</dd>)'
    $LatestVersion = $matches[0]

    Write-Host "Die neuste Version ist aktuell $LatestVersion"

    # Überprüft ob IrfanView aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        Write-Host "Der downlaod von $PName wurde gestartet..."
       
        $url = "https://get.load-balance.net/?802bcf13ece6cd1a7eee7c51689726f841ebf17ce11beebad1"

        $destination = "$env:USERPROFILE\Downloads\IrfanView$LatestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination

        Write-Host "Die Installation von $PName wurde gestartet..."
        Start-Process -FilePath $destination -ArgumentList "/silent" -Wait

        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        echo "$PName ist bereits aktuell in Version $LatestVersion"
    }
   
}

}
