﻿function Update_Java {

Write-Host 
$PName = "Java"
# Überprüft ob Java Installiert ist
$result = & java -version 2>&1 | Select-String 'java version'

if ($result) {
    # Kovertiert die Version in ein gültiges Format
    $version = $result -replace '^java version "(.*)"$', '$1'

    $version = $version.Substring(2)

    $LocalVersion = $version -replace '_', '.'
   
    Write-Host "$PName ist in Version: $LocalVersion installiert"

    # Überprüft die aktuellste Version von Java
    $html = Invoke-WebRequest -Uri "https://www.chip.de/downloads/Java-Runtime-Environment-64-Bit_42224883.html" | Select-Object -ExpandProperty Content

    $regex = [regex]::new("Java Runtime Environment \(64 Bit\) (\d+\.\d+) Update (\d+)")
    $LatestVersion = $regex.Match($html).Groups[1].Value + "." + $regex.Match($html).Groups[2].Value

    Write-Host "Die neuste Version ist aktuell $LatestVersion"

    
    # Überprüft ob Java aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        $url = "https://javadl.oracle.com/webapps/download/AutoDL?BundleId=248242_ce59cff5c23f4e2eaf4e778a117d4c5b"
        $destination = "$env:USERPROFILE\Downloads\java-$LatestVersion-win64.exe"

        Invoke-WebRequest -Uri $url -OutFile $destination
        echo "Der Installation von Java wurde gestartet..."
        Start-Process -FilePath $destination -ArgumentList "/s" -Wait

        

        Write-Host "$PName Installation abgeschlossen"


    }

} else {
    Write-Host "$PName ist nicht installiert"
}

}
