﻿function update_LibreOffice {
$name = "LibreOffice"
Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
Write-Host "Die Verarbeitung von $name wurde gestartet"

# Überprüft ob LibreOffice Installiert ist
if (Test-Path "C:\Program Files\LibreOffice\") {

    # Überprüft die installierte Version 
       try {

        $LocalVersion = (Get-Item "C:\Program Files\LibreOffice\program\scalc.exe" ).VersionInfo.ProductVersion

        if ($LocalVersion.Length -gt 5) {
            # Reduzierung des Strings auf 5 Zeichen
            $LocalVersion = $LocalVersion.Substring(0, 5)
        }
        Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
      
      
     } catch {
        Write-Log -Text " -Error: Die Installierte Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
     }
   

    # Überprüft die aktuelle Version von LibreOffice
    try {
        $html = Invoke-WebRequest -Uri "https://www.libreoffice.org/download/download-libreoffice/" | Select-Object -ExpandProperty Content
        $pattern = '(?<=LibreOffice\s)(\d+(\.\d+){1,2})'
        $LatestVersion = $html | Select-String -Pattern $pattern | ForEach-Object { $_.Matches.Value }

        Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
               
    } catch {
        Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
    }

     # Überprüft ob LibreOffice aktuell ist
    if ($LocalVersion -ne $LatestVersion) {
        # Download von LibreOffice 
        try {
            $url = "https://download.documentfoundation.org/libreoffice/stable/7.6.3/win/x86_64/LibreOffice_7.6.3_Win_x86-64.msi"
            $destination = "C:\Program Files\APA\setups\LibreOffice-$LatestVersion.msi"
        
            Invoke-WebRequest -Uri $url -OutFile $destination -UseBasicParsing
           
            Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
        } catch {
            Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
        }

        # Installation von LibreOffice 
        try {
           Start-Process -FilePath "msiexec" -ArgumentList "/i `"$destination`" /quiet" -Wait
           
           Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"

        } catch {
            Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
        }   
        
    } else {
         Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "green"
    }






} else {
    Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
}
    Write-Host "Verarbeitung von $name abgeschloßen installiert."
    Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"
}
