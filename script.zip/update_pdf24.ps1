﻿function update_pdf24 {
$PName = "PDF24"
Write-Host 
# Überprüft ob PDF24 Installiert ist
if (Test-Path "C:\Program Files\PDF24\pdf24.exe") {
    # Überprüft die Installierte Version von PDF24
    $LocalVersion = (Get-Item "C:\Program Files\PDF24\pdf24.exe" ).VersionInfo.ProductVersion
    Write-Host "$PName ist in Version $localVersion installiert"

    # Überprüft die aktuellste Version von PDF24
    $html = Invoke-WebRequest -Uri "https://www.pdf24.org/de/" | Select-Object -ExpandProperty Content

    # Extrahiert die Version aus dem html Code
    $pattern = '(?<=<span>PDF24 Creator<\/span>\s+)<span>(\d+\.\d+\.\d+)<\/span>'
    $LatestVersion = [regex]::Match($html, $pattern).Groups[1].Value

    Write-Host "Die neuste Version ist aktuell $LatestVersion"

    # Überprüft ob PDF24 aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        Write-Host "Der downlaod von $PName wurde gestartet..."
       

        $url = "https://download.pdf24.org/pdf24-creator-11.13.1-x64.exe"

        $destination = "$env:USERPROFILE\Downloads\pdf24-$LatestVersion.exe"
        $argumente = "/VERYSILENT /NORESTART"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Die Installation von $PName wurde gestartet..."
        
        $process = Start-Process -FilePath $destination -ArgumentList $argumente -Verb RunAs -PassThru

        while (!$process.HasExited) {
            Write-Progress -Activity "Prozess läuft" -Status "Bitte warten..."
            Start-Sleep -Seconds 1
        }

        Write-Progress -Activity "Prozess abgeschlossen" -Status "Fertig" -Completed


        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        echo "$PName ist bereits aktuell in Version $LatestVersion"
    }
}

}
