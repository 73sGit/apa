﻿# Update not work

function update_.NET-Framework {

Write-Host ""
$PName = ".NET Framework" 

# Überprüft die installierten .NET Framework-Versionen
$State = Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -Recurse |
Get-ItemProperty -name Version -EA 0 |
Where-Object { $_.PSChildName -match '^(?!S)\p{L}'} |
Select-Object -Property PSChildName, Version
$version = $state.version[0]
echo "tt " $version

$Version = [Version]$version
$LocalVersion = "{0}.{1}.{2}" -f $Version.Major, $Version.Minor, 0
Write-Host "$PName ist in Version $LocalVersion installiert"

# Überprüft die Latest Version von .NET Framework-Version
$html = Invoke-WebRequest -Uri "https://dotnet.microsoft.com/en-us/download/dotnet-framework" | Select-Object -ExpandProperty Content
$regexPattern = '<a href="/en-us/download/dotnet-framework/net481">\.NET Framework ([\d.]+) '
$LatestVersion = [regex]::Match($html, $regexPattern).Groups[1].Value
Write-Host "Die Latest Version von $PName ist $LatestVersion"

 # Überprüft ob .NET-Framework aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {
        # Aktualisiert das .NET Framework

        $Url = "https://go.microsoft.com/fwlink/?linkid=2088631"
        $destination = "$env:USERPROFILE\Downloads\.NET-Framework-$LatestVersion.exe"

        # Herunterladen des Installationsprogramms
        # Invoke-WebRequest -Uri $Url -OutFile $destination

        # Ausführen der Installation im stillen Modus
        Start-Process -FilePath $destination -ArgumentList "/q /S /norestart" -Wait

        # Überprüfen der Installation
        if ((Get-ChildItem "HKEY:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").PSChildName -like "4.8.*")
        {
            Write-Host "Die .NET Framework 4.8 Installation war erfolgreich."
        }
        else
        {
            Write-Host "Die .NET Framework 4.8.1-Installation ist fehlgeschlagen."
        }
       
    } else {
        Write-Host "$PName ist bereits aktuell in Version $LatestVersion"
    }







}
