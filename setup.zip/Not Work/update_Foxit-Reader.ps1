﻿# Silent Install not working

function update_Foxit-Reader {
$PName = "Foxit-Reader"
Write-Host 
# Überprüft ob Foxit PDF Reader Installiert ist
if (Test-Path "C:\Program Files (x86)\Foxit Software\Foxit PDF Reader\FoxitPDFReader.exe") {
    # Überprüft die Installierte Version von Foxit PDF Reader
    $LocalVersion = (Get-Item "C:\Program Files (x86)\Foxit Software\Foxit PDF Reader\FoxitPDFReader.exe" ).VersionInfo.ProductVersion 

    Write-Host "$PName ist in Version $localVersion installiert"

    # Überprüft die aktuellste Version von 
    $html = Invoke-WebRequest -Uri "https://www.foxit.com/de/pdf-reader/version-history.html" | Select-Object -ExpandProperty Content
    
    $LatestVersion = [regex]::Match($html, "(?<=<h3>Version\s)\d+\.\d+\.\d+\.\d+").Value

    # Ausgabe der Versionsnummer
    Write-Host "Die neuste Version ist aktuell $LatestVersion"

      # Überprüft ob Foxit aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {
        Write-Host "Der Download von $PName wurde gestartet..."
        $url = "https://cdn01.foxitsoftware.com/product/reader/desktop/win/12.1.2/FoxitPDFReader1212_L10N_Setup.msi"
        $destination = "$env:USERPROFILE\Downloads\Foxit-$LatestVersion.msi"
        # Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Die Installation von $PName wurde gestartet..."
      
        # Start Process does not working
        # Start-Process -FilePath "msiexec.exe" -ArgumentList "/quiet INSTALLLOCATION='$destinatin'" -force -Wait


        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        echo "$PName ist bereits aktuell in Version $LatestVersion"
    }

}

}
