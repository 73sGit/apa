# Funktion zum Convertieren der Version
function convertVersion
{
    param(
        [String]$name,
        [string]$version
    )

    if ($name -eq "Audacity" ) {
        $version = $version.Substring(0, $version.Length - 2)
        $version = $version -replace ",", "."
        return $version
    }

    if ($name -eq "VLC-Media Player" ) {
        $version = $version.Substring(0, $version.Length - 2)
        $version = $version -replace ",", "."
        return $version
    }

    if ($name -eq "TeamViewer" ) {
        $version = $version.Substring(0, $version.Length - 2)
        $version = $version -replace ",", "."
        return $version
    }

    if ($name -eq "PaintNet" ) {
        $version = $version.Substring(0, 3)
        $version = $version.Insert(1, ".0")
        return $version
    }

    return $version
}


function checkIfInstalled {
    param(
        [String]$name
    )

    if ($name -eq "Filius" ) {
        return (Get-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Filius").DisplayVersion
    }

    if ($name -eq "Java" ) {
        $result = & java -version 2>&1 | Select-String 'java version'
        $version = $result -replace '^java version "(.*)"$', '$1'
        $version = $version.Substring(2)
        return $installedVersion = $version -replace '_', '.'
    }

    return $version
}

function getLatestVersion {
    param(
        [String]$name
    )

    if ($name -eq "Filius" ) {
        $matches = [regex]::Matches($html, $app.regex)
        $data[$app.Position].LatestVersion = $matches[0].Value
        $LatestVersion = $data[$app.Position].LatestVersion
    }

    if ($name -eq "Java" ) {
        $html = Invoke-WebRequest -Uri "https://www.chip.de/downloads/Java-Runtime-Environment-64-Bit_42224883.html" | Select-Object -ExpandProperty Content
        $regex = [regex]::new("Java Runtime Environment \(64 Bit\) (\d+\.\d+) Update (\d+)")
        $LatestVersion = $regex.Match($html).Groups[1].Value + "." + $regex.Match($html).Groups[2].Value
    }

    if ($name -eq "PaintNet" ) {
        Write-Host 'tst'
        $html = Invoke-WebRequest -Uri "https://www.dotpdn.com/downloads/pdn.html#google_vignette" | Select-Object -ExpandProperty Content
        $pattern = 'paint.net\s+(\d+\.\d+\.\d+)'
        $matches = [regex]::Matches($html, $pattern)
        $LatestVersion = $matches[0].Groups[1].Value
    }

    return $LatestVersion




}