# Funktion zum Konvertieren von farbigem Text in HTML
function ConvertTo-HTMLColorText {
    param (
        [string]$Text,
        [string]$ForegroundColor
    )

    $htmlText = "<font color='$ForegroundColor'>$Text</font>"
    return $htmlText
}

# Funktion zum Schreiben von farbigem Text in eine HTML-Datei
function Write-Log {
    param (
        [string]$Text,
        [string]$FilePath,
        [string]$ForegroundColor
    )

    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $Text = $Timestamp + $Text
    $formattedText = ConvertTo-HTMLColorText -Text $Text -ForegroundColor $ForegroundColor
    $formattedText | Out-File -Append -FilePath $FilePath
}

# Verwendung der Funktion
$LogFile = ".\Logdatei.html"



