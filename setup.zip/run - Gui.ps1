# Imports
. "C:\script\APA AppAutoUpdate\Script\checkSoftware.ps1"
. "C:\script\APA AppAutoUpdate\Script\runUpdateSelectedProgramm.ps1"

$data = checkSoftware

# Init PowerShell Gui
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Create a new form
$Form = New-Object system.Windows.Forms.Form
$Form.Size = New-Object Drawing.Size(1100, 700)
$Form.StartPosition = "CenterScreen"
$Form.Text = "APAA-App & Programm Aktualisierungs Assistant --Webler Verison 1.0 -Alpha"
$Form.BackColor = "#ffffff"



# Description
$Description = New-Object system.Windows.Forms.Label
$Description.Text = "Sie k�nnen APAA-Aktualisierung nutzen um Programme zu aktualisieren!"
$Description.AutoSize = $true
$Description.Width = 450
$Description.Height = 0
$Description.Location = New-Object Drawing.Point(30, 40)
$Description.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)

####################################################################################################
# Label
if ($true)
{








}
####################################################################################################

function CreateLabel {
    param(
        [string]$text,
        [int]$top,
        [int]$bgColor
    )
    $label = New-Object Windows.Forms.Label
    $label.Text = $text
    $label.Width = 195
    $label.Location = New-Object Drawing.Point(50, $top)
    $label.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
    $label.ForeColor = [System.Drawing.Color]::Black
    $label.BackColor = [System.Drawing.Color]::FromArgb($bgColor, $bgColor, $bgColor)
    $label.BorderStyle = 'Fixed3D'
    $label.TextAlign = 'MiddleCenter'

    return $label
}

function CreateInstalledVersionLabel {
    param(
        [string]$version,
        [int]$top,
        [int]$bgColor
    )
    $label = New-Object Windows.Forms.Label
    $label.Text = $version
    $label.Width = 195
    $label.Location = New-Object Drawing.Point(250, $top)
    $label.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
    $label.ForeColor = [System.Drawing.Color]::Black
    $label.BackColor = [System.Drawing.Color]::FromArgb($bgColor, $bgColor, $bgColor)
    $label.BorderStyle = 'Fixed3D'
    $label.TextAlign = 'MiddleCenter'

    return $label
}

function CreateLatestVersionLabel {
    param(
        [string]$version,
        [int]$top,
        [int]$bgColor
    )
    $label = New-Object Windows.Forms.Label
    $label.Text = $version
    $label.Width = 195
    $label.Location = New-Object Drawing.Point(450, $top)
    $label.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
    $label.ForeColor = [System.Drawing.Color]::Black
    $label.BackColor = [System.Drawing.Color]::FromArgb($bgColor, $bgColor, $bgColor)
    $label.BorderStyle = 'Fixed3D'
    $label.TextAlign = 'MiddleCenter'

    return $label
}

function CreateStatusLabel {
    param(
        [string]$status,
        [int]$top,
        [int]$bgColor
    )
    $label = New-Object Windows.Forms.Label
    $label.Text = $status
    $label.Width = 195
    $label.Location = New-Object Drawing.Point(650, $top)
    $label.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
    $label.ForeColor = [System.Drawing.Color]::Black
    $label.BackColor = [System.Drawing.Color]::FromArgb($bgColor, $bgColor, $bgColor)
    $label.BorderStyle = 'Fixed3D'
    $label.TextAlign = 'MiddleCenter'

    return $label
}

function CreateButton {
    param(
        [string]$text,
        [int]$top,
        [int]$bgColor
    )
    $button = New-Object Windows.Forms.Button
    $button.Text = $text
    $button.Width = 195
    $button.Location = New-Object Drawing.Point(850, $top)
    $button.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)

    return $button
}

# Definiere eine Funktion f�r den Button-Click-Event-Handler
function CreateButtonClickHandler {
    param(
        [int]$index,
        [string]$name
    )

    Write-Host "hase"
    Write-Host $name

    if ($data[$index].status -eq "Update verf�gbar")
    {
        $update = $true
        $Statusbar.Text = "Das Update f�r $name wurde gestartet..."

    }
    elseif ($data[$index].status -eq "Nicht installiert")
    {
        $update = $false
        $Statusbar.Text = "$name ist nicht Installiert"
    }
    else
    {
        $update = $false
        $Statusbar.Text = "Kein Update f�r $name verf�gbar"
    }

    if ($update)
    {
        if ($name -eq "7-Zip") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV1.Text
            $Statusbar.Text = $obj.statusbar
            $InstalledV1.Text = $obj.installedV
            $Status1.Text = $obj.status
        }

        if ($name -eq "Audacity") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV2.Text

            $Statusbar.Text = $obj.statusbar
            $InstalledV2.Text = $obj.installedV
            $Status2.Text = $obj.status
        }

        if ($name -eq "Filius") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV3.Text
            $Statusbar.Text = $obj.statusbar
            $InstalledV3.Text = $obj.installedV
            $Status3.Text = $obj.status
        }

        if ($name -eq "VLC-Media Player") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV4.Text
            $Statusbar.Text = $obj.statusbar
            $InstalledV4.Text = $obj.installedV
            $Status4.Text = $obj.status
        }

        if ($name -eq "TeamViewer") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV5.Text
            $Statusbar.Text = $obj.statusbar
            $InstalledV5.Text = $obj.installedV
            $Status5.Text = $obj.status
        }

        if ($name -eq "Inkscape") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV6.Text
            $Statusbar.Text = $obj.statusbar
            $InstalledV6.Text = $obj.installedV
            $Status6.Text = $obj.status
        }

        if ($name -eq "Java") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV7.Text
            $Statusbar.Text = $obj.statusbar
            $InstalledV7.Text = $obj.installedV
            $Status7.Text = $obj.status
        }

        if ($name -eq "PDF24-Creator") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV8.Text
            $Statusbar.Text = $obj.statusbar
            $InstalledV8.Text = $obj.installedV
            $Status8.Text = $obj.status
        }

        if ($name -eq "PaintNet") {
            $obj = runUpdateSelectedProgramm -programmName $name -latestVersion $LatestV9.Text
            $Statusbar.Text = $obj.statusbar
            $InstalledV9.Text = $obj.installedV
            $Status9.Text = $obj.status
        }
    }
}

# Title
$Titel = New-Object system.Windows.Forms.Label
$Titel.text = "App und Programm Aktualisierungs Assistant"
$Titel.AutoSize = $true
$Titel.width = 25
$Titel.height = 10
$Titel.location = New-Object System.Drawing.Point(30, 10)
$Titel.Font = 'Microsoft Sans Serif,12'


# Create the Label for Button
$Label_Button = New-Object Windows.Forms.Label
$Label_Button.Text = 'Aktualisieren'
$Label_Button.Width = 195
$Label_Button.Location = New-Object Drawing.Point(850, 100)
$Label_Button.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
$Label_Button.ForeColor = [System.Drawing.Color]::Black # Custom text color
$Label_Button.BackColor = [System.Drawing.Color]::FromArgb(211, 211, 211)
$Label_Button.BorderStyle = 'Fixed3D' # Add a border to the label
$Label_Button.TextAlign = 'MiddleCenter' # Align text to the center of the label


$Label_Name = CreateLabel -text 'Name' -top 100 -bgColor 211
$Label_InstalledV = CreateInstalledVersionLabel -version 'Installierte Version' -top 100 -bgColor 211
$Label_LatestV = CreateLatestVersionLabel -version 'Aktuelle Version' -top 100 -bgColor 211
$Label_Status = CreateStatusLabel -status "Status" -top 100 -bgColor 211


$Name1 = CreateLabel -text '7-Zip' -top 130 -bgColor 240
$InstalledV1 = CreateInstalledVersionLabel -version $data[0].installedVersion -top 130 -bgColor 240
$LatestV1 = CreateLatestVersionLabel -version $data[0].latestVersion -top 130 -bgColor 240
$Status1 = CreateStatusLabel -status $data[0].status -top 130 -bgColor 240
$Button1 = CreateButton -text "Aktualisieren" -top 130 -bgColor 240
$Button1.Add_Click({CreateButtonClickHandler -index 0 -name "7-Zip"})


$Name2 = CreateLabel -text 'Audacity' -top 160 -bgColor 240
$InstalledV2 = CreateInstalledVersionLabel -version $data[1].installedVersion -top 160 -bgColor 240
$LatestV2 = CreateLatestVersionLabel -version $data[1].latestVersion -top 160 -bgColor 240
$Status2 = CreateStatusLabel -status $data[1].status -top 160 -bgColor 240
$Button2 = CreateButton -text "Aktualisieren" -top 160 -bgColor 240
$Button2.Add_Click({CreateButtonClickHandler -index 1 -name "Audacity"})


$Name3 = CreateLabel -text 'Filius' -top 190 -bgColor 240
$InstalledV3 = CreateInstalledVersionLabel -version $data[2].installedVersion -top 190 -bgColor 240
$LatestV3 = CreateLatestVersionLabel -version $data[2].latestVersion -top 190 -bgColor 240
$Status3 = CreateStatusLabel -status $data[2].status -top 190 -bgColor 240
$Button3 = CreateButton -text "Aktualisieren" -top 190 -bgColor 240
$Button3.Add_Click({CreateButtonClickHandler -index 2 -name "Filius"})

$Name4 = CreateLabel -text 'VLC-Media Player' -top 220 -bgColor 240
$InstalledV4 = CreateInstalledVersionLabel -version $data[3].installedVersion -top 220 -bgColor 240
$LatestV4 = CreateLatestVersionLabel -version $data[3].latestVersion -top 220 -bgColor 240
$Status4 = CreateStatusLabel -status $data[3].status -top 220 -bgColor 240
$Button4 = CreateButton -text "Aktualisieren" -top 220
$Button4.Add_Click({CreateButtonClickHandler -index 3 -name "VLC-Media Player"})

$Name5 = CreateLabel -text 'TeamViewer' -top 250 -bgColor 240
$InstalledV5 = CreateInstalledVersionLabel -version $data[4].installedVersion -top 250 -bgColor 240
$LatestV5 = CreateLatestVersionLabel -version $data[4].latestVersion -top 250 -bgColor 240
$Status5 = CreateStatusLabel -status $data[4].status -top 250 -bgColor 240
$Button5 = CreateButton -text "Aktualisieren" -top 250 -bgColor 240
$Button5.Add_Click({CreateButtonClickHandler -index 4 -name "TeamViewer"})

$Name6 = CreateLabel -text 'Inkscape' -top 280 -bgColor 240
$InstalledV6 = CreateInstalledVersionLabel -version $data[5].installedVersion -top 280 -bgColor 240
$LatestV6 = CreateLatestVersionLabel -version $data[5].latestVersion -top 280 -bgColor 240
$Status6 = CreateStatusLabel -status $data[5].status -top 280 -bgColor 240
$Button6 = CreateButton -text "Aktualisieren" -top 280 -bgColor 240
$Button6.Add_Click({CreateButtonClickHandler -index 5 -name "Inkscape"})

$Name7 = CreateLabel -text 'Java' -top 310 -bgColor 240
$InstalledV7 = CreateInstalledVersionLabel -version $data[6].installedVersion -top 310 -bgColor 240
$LatestV7 = CreateLatestVersionLabel -version $data[6].latestVersion -top 310 -bgColor 240
$Status7 = CreateStatusLabel -status $data[6].status -top 310 -bgColor 240
$Button7 = CreateButton -text "Aktualisieren" -top 310 -bgColor 240
$Button7.Add_Click({CreateButtonClickHandler -index 6 -name "Java"})

$Name8 = CreateLabel -text 'PDF24-Creator' -top 340 -bgColor 240
$InstalledV8 = CreateInstalledVersionLabel -version $data[7].installedVersion -top 340 -bgColor 240
$LatestV8 = CreateLatestVersionLabel -version $data[7].latestVersion -top 340 -bgColor 240
$Status8 = CreateStatusLabel -status $data[7].status -top 340 -bgColor 240
$Button8 = CreateButton -text "Aktualisieren" -top 340 -bgColor 240
$Button8.Add_Click({CreateButtonClickHandler -index 7 -name "PDF24-Creator"})

$Name9 = CreateLabel -text 'PaintNet' -top 370 -bgColor 240
$InstalledV9 = CreateInstalledVersionLabel -version $data[8].installedVersion -top 370 -bgColor 240
$LatestV9 = CreateLatestVersionLabel -version $data[8].latestVersion -top 370 -bgColor 240
$Status9 = CreateStatusLabel -status $data[8].status -top 370 -bgColor 240
$Button9 = CreateButton -text "Aktualisieren" -top 370 -bgColor 240
$Button9.Add_Click({CreateButtonClickHandler -index 8 -name "PaintNet"})


# F�ge die Labels zum Formular hinzu
$form.Controls.AddRange(@($Name1, $Name2, $Name3, $Name4, $Name5, $Name6, $Name7, $Name8, $Name9))
$form.Controls.AddRange(@($InstalledV1, $InstalledV2, $InstalledV3, $InstalledV4, $InstalledV5, $InstalledV6, $InstalledV7, $InstalledV8, $InstalledV9))
$form.Controls.AddRange(@($LatestV1, $LatestV2, $LatestV3, $LatestV4,$LatestV5, $LatestV6, $LatestV7, $LatestV8, $LatestV9 ))
$form.Controls.AddRange(@($Status1, $Status2, $Status3, $Status4,$Status5, $Status6, $Status7, $Status8, $Status9))
$form.Controls.AddRange(@($Button1, $Button2, $Button3, $Button4, $Button5, $Button6, $Button7, $Button8, $Button9))

$Statusbar = New-Object Windows.Forms.Label
$Statusbar.Text = 'Statusbar'
$Statusbar.Width = 1025
$Statusbar.Location = New-Object Drawing.Point(30, 500)
$Statusbar.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
$Statusbar.ForeColor = [System.Drawing.Color]::Black # Custom text color
$Statusbar.BackColor = [System.Drawing.Color]::FromArgb(211, 211, 211)

$Statusbar.BorderStyle = 'Fixed3D' # Add a border to the label
$Statusbar.TextAlign = 'MiddleCenter' # Align text to the center of the label

####################################################################################################

# Add the description label to the form
$Form.Controls.Add($Titel)
$Form.Controls.Add($Description)

# Add From Attributes for Label
$Form.Controls.Add($Label_Name)
$Form.Controls.Add($Label_InstalledV)
$Form.Controls.Add($Label_LatestV)
$Form.Controls.Add($Label_Status)
$Form.Controls.Add($Label_Button)


# Add From Attributes for Statusbar and Dispaly the form
$Form.Controls.Add($Statusbar)
$Form.ShowDialog()


####################################################################################################
######################################################################


####################################################################################################
<## Gimp
if ($true)
{
    # Create the Fields for Gimp
    $Name10 = New-Object Windows.Forms.Label
    $Name10.Text = 'Gimp'
    $Name10.Width = 195
    $Name10.Location = New-Object Drawing.Point(50, 400)
    $Name10.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
    $Name10.ForeColor = [System.Drawing.Color]::Black # Custom text color
    $Name10.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)
    $Name10.BorderStyle = 'Fixed3D' # Add a border to the label
    $Name10.TextAlign = 'MiddleCenter' # Align text to the center of the label

    # Create the InstalledVersion Field for Gimp
    $InstalledV10 = New-Object Windows.Forms.Label
    $InstalledV10.Text = $data[9].installedVersion
    $InstalledV10.Width = 195
    $InstalledV10.Location = New-Object Drawing.Point(250, 400)
    $InstalledV10.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
    $InstalledV10.ForeColor = [System.Drawing.Color]::Black # Custom text color
    $InstalledV10.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)
    $InstalledV10.BorderStyle = 'Fixed3D' # Add a border to the label
    $InstalledV10.TextAlign = 'MiddleCenter' # Align text to the center of the label

    # Create the LatestVersion Field for Gimp
    $LatestV10 = New-Object Windows.Forms.Label
    $LatestV10.Text = $data[9].latestVersion
    $LatestV10.Width = 195
    $LatestV10.Location = New-Object Drawing.Point(450, 400)
    $LatestV10.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
    $LatestV10.ForeColor = [System.Drawing.Color]::Black # Custom text color
    $LatestV10.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)
    $LatestV10.BorderStyle = 'Fixed3D' # Add a border to the label
    $LatestV10.TextAlign = 'MiddleCenter' # Align text to the center of the label

    # Create the Status for Gimp
    $Status10 = New-Object Windows.Forms.Label
    $Status10.Text = $data[9].status
    $Status10.Width = 195
    $Status10.Location = New-Object Drawing.Point(650, 400)
    $Status10.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)
    $Status10.ForeColor = [System.Drawing.Color]::Black # Custom text color
    $Status10.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)
    $Status10.BorderStyle = 'Fixed3D' # Add a border to the label
    $Status10.TextAlign = 'MiddleCenter' # Align text to the center of the label

    # Create the button for Paint
    $Button10 = New-Object Windows.Forms.Button
    $Button10.Text = "Aktualisieren"
    $Button10.Width = 195
    $Button10.Location = New-Object Drawing.Point(850, 400)
    $Button10.Font = New-Object Drawing.Font('Microsoft Sans Serif', 10)

    # Event handler for PaintNet
    $Button10.Add_Click({
        $update = $false

        if ($Status10.Text -eq "Update verf�gbar")
        {
            $update = $true
            $Statusbar.Text = "Das Update f�r Gimp wurde gestartet..."

        }
        elseif ($Status10.Text -eq "Nicht installiert")
        {
            $Statusbar.Text = "Gimp ist nicht Installiert"
        }
        else
        {
            $Statusbar.Text = "Kein Update f�r Gimp verf�gbar"
        }
        Write-Host $update

        if ($update)
        {
            $obj = runUpdateSelectedProgramm -programmName "Gimp" -latestVersion $LatestV10.Text

            $Statusbar.Text = $obj.statusbar
            $InstalledV10.Text = $obj.installedV
            $Status10.Text = $obj.status
        }
    })
}#>
####################################################################################################
# Create Statusbar


