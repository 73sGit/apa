function Run {

Import-Module -Name .\script\update_7zip.ps1
Import-Module -Name .\script\update_vlc.ps1

. ".\script\update_7zip.ps1"
. ".\script\update_vlc.ps1"

Update_7zip
Update_vlc


}