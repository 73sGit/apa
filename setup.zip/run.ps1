function Run {

Import-Module -Name .\script\update_7zip.ps1

. ".\script\update_7zip.ps1"

Update_7zip


}