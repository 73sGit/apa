function Run {

Import-Module -Name .\script\update_teamviewer.ps1
Import-Module -Name .\script\update_7zip.ps1
Import-Module -Name .\script\update_vlc.ps1
Import-Module -Name .\script\update_audacity.ps1
Import-Module -Name .\script\update_java.ps1
Import-Module -Name .\script\update_gimp.ps1
Import-Module -Name .\script\update_filius.ps1
Import-Module -Name .\script\update_LibreOffice.ps1
Import-Module -Name .\script\update_pdf24.ps1
Import-Module -Name .\script\update_airServer.ps1


. ".\script\update_teamviewer.ps1"
. ".\script\update_7zip.ps1"
. ".\script\update_vlc.ps1"
. ".\script\update_audacity.ps1"
. ".\script\update_java.ps1"
. ".\script\update_gimp.ps1"
. ".\script\update_filius.ps1"
. ".\script\update_LibreOffice.ps1"
. ".\script\update_IrfanView.ps1"
. ".\script\update_pdf24.ps1"
. ".\script\update_airServer.ps1"

Update_teamviewer
Update_7zip
Update_vlc
Update_audacity
Update_java
Update_gimp
Update_filius
Update_LibreOffice
Update_IrfanView
Update_pdf24
Update_airServer

}