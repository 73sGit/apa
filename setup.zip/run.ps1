function Run {

Write-Host "Hase"
Import-Module -Name .\script\update_7zip.ps1

. ".\script\update_7zip.ps1"

Update_7zip

Write-Host "AFfe"
#Update_teamViewer
#Update_VLC
#Update_XChange
#Update_PDF24
#Update_Java
#Update_PaintNet
#Update_Firefox

#Update_geoGebra_classic
#Update_Inkscape
#Update_filius
#Update_audacity
#Update_Gimp
}