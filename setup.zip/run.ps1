function Run {

Import-Module -Name .\script\update_teamviewer.ps1
Import-Module -Name .\script\update_7zip.ps1
Import-Module -Name .\script\update_vlc.ps1
Import-Module -Name .\script\update_audacity.ps1
Import-Module -Name .\script\update_java.ps1
Import-Module -Name .\script\update_gimp.ps1
Import-Module -Name .\script\update_filius.ps1
Import-Module -Name .\script\update_LibreOffice.ps1
Import-Module -Name .\script\update_pdf24.ps1
Import-Module -Name .\script\update_airServer.ps1
Import-Module -Name .\script\update_Firefox.ps1
Import-Module -Name .\script\update_Inkscape.ps1



. ".\script\update_teamviewer.ps1"
. ".\script\update_7zip.ps1"
. ".\script\update_vlc.ps1"
. ".\script\update_audacity.ps1"
. ".\script\update_java.ps1"
. ".\script\update_gimp.ps1"
. ".\script\update_filius.ps1"
. ".\script\update_LibreOffice.ps1"
. ".\script\update_IrfanView.ps1"
. ".\script\update_pdf24.ps1"
. ".\script\update_airServer.ps1"
. ".\script\update_Firefox.ps1"
. ".\script\update_inkscape.ps1"

update_teamviewer
update_7zip
update_vlc
update_audacity
update_java
update_gimp
update_filius
update_LibreOffice
update_IrfanView
update_pdf24
update_airServer
update_Firefox
update_inkscape

}