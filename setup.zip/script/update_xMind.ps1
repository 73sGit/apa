﻿function update_xMind {
$PName = "XMind"
Write-Host ""
# Überprüft ob XMind Installiert ist
if (Test-Path "$env:USERPROFILE\AppData\Local\Programs\Xmind") {
    # Überprüft die Installierte Version von XMind
    $LocalVersion = (Get-Item "$env:USERPROFILE\AppData\Local\Programs\Xmind\Xmind.exe" ).VersionInfo.ProductVersion
    $LocalVersion = $LocalVersion.Substring(0, 10)

    Write-Host "$PName ist in Version $LocalVersion installiert"

    # Überprüft die aktuellste Version von XMind
    $html = Invoke-WebRequest -Uri "https://xmind.app/de/desktop/release-notes/" | Select-Object -ExpandProperty Content

    $regexPattern = '(?<=<h3 class="mt-5 mb-1">)(.*?)(?=<\/h3>)'
    $match = $html -match $regexPattern

    if ($match) {
        $extractedValue = $matches[0]
        $LatestVersion = $extractedValue -replace '\s*\((\d{4})\d+\)', '.$1'

        Write-Host "Die neuste Version von XMind ist $LatestVersion" 
    } else {
        Write-Output "Version von XMind konnte nicht aktualisiert werden."
    }

    # Überprüft ob XMind aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        # Startet den Download von XMind 
        Write-Host "Der downlaod von $PName wurde gestartet..."       
           
        $url = "https://www.xmind.app/zen/download/win64/"
        $destination = "$env:USERPROFILE\Downloads\XMind-$LatestVersion.exe"
        Invoke-WebRequest -Uri $url -OutFile $destination
            
        # Startet die Installation von XMind
        Write-Host "Die Installation von $PName wurde gestartet..."
        
        Start-Process -FilePath "$destination" -ArgumentList "/s /qn" -Wait
        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        Write-Host "$PName ist bereits aktuell in Version $LatestVersion"
    }


   
        
} else {
    Write-Host "$PName ist bereits aktuell in Version $LatestVersion"
    
}

}
