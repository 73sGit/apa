﻿function Update_7zip {
$name = "7-Zip"

Write-Log -Text "$Timestamp -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "green"
Write-Host "Die Verarbeitung von $name wurde gestartet"

# Überprüft ob 7 Zip Installiert ist
if (Test-Path "C:\Program Files\7-Zip\7z.exe") {
    # Überprüft die Installierte Version von 7-Zip
    $LocalVersion = (Get-Item "C:\Program Files\7-Zip\7z.exe" ).VersionInfo.ProductVersion
   
    Write-Log -Text "$Timestamp -Info: $name ist in Version: $localVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"

    # Überprüft die aktuellste Version von 7-Zip
     try {
        $webClient = New-Object System.Net.WebClient
        $html = $webClient.DownloadString("https://www.7-zip.org/download.html")
   
     } catch {
        Write-Log -Text "$Timestamp -Error: Der Downlaod von dem HTML-Code von $name zur ermittlung der Version ist fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text "Timestamp -Error: $_" -FilePath $LogFile -ForegroundColor "red"
        Write-Host "Fehler aufgetreten: $_"
     }
    
    $LatestVersion = [regex]::Match($html, 'Download 7-Zip ([\d.]+)').Groups[1].Value
    
    Write-Log -Text "$Timestamp -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"

    # Überprüft ob 7-Zip Aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        $link_version = $LatestVersion.Replace(".", "")    
        $url = "https://www.7-zip.org/a/7z$link_Version-x64.exe"
        $destination = "$env:USERPROFILE\Downloads\7zip-$LatestVersion.exe"

        try {
            Invoke-WebRequest -Uri $url -OutFile $destination -UseBasicParsing
            Write-Log -Text "$Timestamp -Info: Download von $name Setup wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
         } catch {
            Write-Log -Text "$Timestamp -Error: Download - $name-Setup erfolgreich erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
         }

         try {
            Start-Process -FilePath $destination -ArgumentList "/S" -Wait
             Write-Log -Text "$Timestamp -Info: Aktualisierung von $name erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
         } catch {
             Write-Log -Text "$Timestamp -Info: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
         }
        
    } else {
        Write-Log -Text "$Timestamp -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "black"
    }
   
} else {
    Write-Log -Text "$Timestamp -Info: Aktualisierung nicht notwendig, da nicht installiert <br>" -FilePath $LogFile -ForegroundColor "#000CD"
}
    Write-Host "Die Verarbeitung von $name wurde abgeschlossen"
    Write-Log -Text "$Timestamp -Info: Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
    Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"
}
