﻿function update_Firefox {

    $name = "Firefox"

    Write-Host "Die Verarbeitung von $name wurde gestartet"
    Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"

    # Überprüft ob Firefox Installiert ist
    if (Test-Path "C:\Program Files\Mozilla Firefox") {
        Write-Host "$PName ist installiert."

       # Überprüft die Installierte Version
        try {
            $LocalVersion = (Get-ItemPropertyValue -Path 'HKLM:\SOFTWARE\Mozilla\Mozilla Firefox' -Name "CurrentVersion")

            Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
        } catch {
            Write-Log -Text " -Info: Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        }

        # Überprüft die aktuellste Version 
        try {
            $html = Invoke-WebRequest -Uri "https://www.chip.de/downloads/Firefox-64-Bit_85086969.html" | Select-Object -ExpandProperty Content

            $pattern = 'Version\s+(\d+\.\d+\.\d+)'
            $LatestVersion = [regex]::Match($html, $pattern).Groups[1].Value
           
            Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
               
        } catch {
            Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
        }

        # Überprüft ob Firefox aktualisiert werden muss
        if ($LocalVersion -ne $LatestVersion) {
            try {
                $url = "https://download.mozilla.org/?product=firefox-msi-latest-ssl&os=win64&lang=de"

                $folderPath = "C:\Program Files\APA\setups"

                if (-not (Test-Path -Path $folderPath -PathType Container)) {
                    New-Item -ItemType Directory -Path $folderPath -Force
                    Write-Host "Folder created: $folderPath"
                } 
                      
                $destination = "$folderPath\firefox$LatestVersion.msi"
                $msiExecArgs = "/i `"$destination`" /quiet"
             
                Invoke-WebRequest -Uri $url -OutFile $destination

                Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"

            } catch {
                Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            } 

            # Startet die Installation 
            try {
                $msiExecArgs = "/i `"$destination`" /quiet"
                Start-Process -FilePath "msiexec" -ArgumentList $msiExecArgs -Wait
                Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"

            } catch {
                Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            
           }

       }
    }
}