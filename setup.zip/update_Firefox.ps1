﻿function update_Firefox {

$PName = "Firefox"
Write-Host 
# Überprüft ob Firefox Installiert ist
if (Test-Path "C:\Program Files\Mozilla Firefox\Firefox.exe") {
    Write-Host "$PName ist installiert."

    # Überprüft die Installierte Version von Firefox
    $LocalVersion = (Get-Item "C:\Program Files\Mozilla Firefox\Firefox.exe" ).VersionInfo.ProductVersion
    Write-Host "$PName ist in Version $localVersion installiert"
    
    # Überprüft die Installierte Version von Firefox" 
    $html = Invoke-WebRequest -Uri "https://www.chip.de/downloads/Firefox-64-Bit_85086969.html" | Select-Object -ExpandProperty Content
   
    $regex = 'Firefox in Version (\d+\.\d+\.\d+)'
    $match = [regex]::Match($html, $regex)

   
    $LatestVersion = $match.Groups[1].Value
    Write-Host "Die neuste Version ist aktuell $LatestVersion"

    # Überprüft ob Firefox aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {
        Write-Host "Der Download von $PName wurde gestartet..."
        $url = "https://download.mozilla.org/?product=firefox-msi-latest-ssl&os=win64&lang=de&attribution_code=c291cmNlPXd3dy5nb29nbGUuY29tJm1lZGl1bT1yZWZlcnJhbCZjYW1wYWlnbj0obm90IHNldCkmY29udGVudD0obm90IHNldCkmZXhwZXJpbWVudD0obm90IHNldCkmdmFyaWF0aW9uPShub3Qgc2V0KSZ1YT1jaHJvbWUmY2xpZW50X2lkPTc5Mjc4NTgzNS4xNjg1MTA3MDM0JnNlc3Npb25faWQ9NDkyMzkxMDkxMyZkbHNvdXJjZT1tb3pvcmc.&attribution_sig=df54aecb1ca4acc50b802fae443721530ac7f2c2f89b0cfffb05dedff8b3347d&_gl=1*wo133h*_ga*NzkyNzg1ODM1LjE2ODUxMDcwMzQ.*_ga_MQ7767QQQW*MTY4OTU5NDIxOC4yLjEuMTY4OTU5NDIzMC4wLjAuMA.."
        $destination = "$env:USERPROFILE\Downloads\Firefox-$LatestVersion.msi"
        Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Die Installation von $PName wurde gestartet..."
        $msiExecArgs = "/i `"$destination`" /quiet"
        Start-Process -FilePath "msiexec" -ArgumentList $msiExecArgs -Wait

        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        echo "$PName ist bereits aktuell in Version $LatestVersion"
    }
           
    else {
    Write-Host "$PName ist nicht installiert."
}


}
}