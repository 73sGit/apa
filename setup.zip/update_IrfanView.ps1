﻿function update_IrfanView {
    $name = "IrfanView"

    Write-Host "Die Verarbeitung von $name wurde gestartet"
    Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"

    # Überprüft ob IrfanView Installiert ist
    if (Test-Path "C:\Program Files\IrfanView\i_view64.exe") {

        # Überprüft die Installierte Version von IrfanView
        try {
            $LocalVersion = (Get-Item "C:\Program Files\IrfanView\i_view64.exe" ).VersionInfo.ProductVersion 

	        $LocalVersion = $LocalVersion.Split('.')
            $LocalVersion = $LocalVersion[0] + "." + $LocalVersion[1]

            Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
        } catch {
            Write-Log -Text " -Info: Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        }

        # Überprüft die aktuellste Version 
        try {
            $html = Invoke-WebRequest -Uri "https://www.fosshub.com/IrfanView-DE.html" | Select-Object -ExpandProperty Content

            $LatestVersion = [regex]::Match($html , '(?<=softwareVersion">)[\d.]+').Value

            Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
               
        } catch {
            Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
        }

         # Überprüft ob IrfanView aktualisiert werden muss
        if ($LocalVersion -ne $LatestVersion) {
            try {
                $url = "https://download.heise.de/files/j0atSQzS8dq-mb3yqspsKg/309059/iview466_setup.exe?expires=1704194327"
                        

                $folderPath = "C:\Program Files\APA\setups"

                if (-not (Test-Path -Path $folderPath -PathType Container)) {
                    New-Item -ItemType Directory -Path $folderPath -Force
                    Write-Host "Folder created: $folderPath"
                } 
                      
                $destination = "$folderPath\irfanView-$LatestVersion.exe"
                Invoke-WebRequest -Uri $url -OutFile $destination

                Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"

            } catch {
                Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            } 

            # Startet die Installation 
            try {
                Start-Process -FilePath $destination -ArgumentList "/silent" -Wait
                Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"

            } catch {
                Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            
           }

       }

     
    } else {
        
        Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
    }
        Write-Host "Verarbeitung von $name abgeschloßen installiert."
        Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"
}

 
      
        

         

       
