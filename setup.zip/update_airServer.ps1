function update_AirServer {

    $name = "AirServer"
    
    Write-Host "Die Verarbeitung von $name wurde gestartet"
    Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"

    # Überprüft ob AirServer Installiert ist
    if (Test-Path "C:\Program Files\App Dynamic\AirServer") {

        # Überprüft die Version
        try {
            $LocalVersion = (Get-Item "C:\Program Files\App Dynamic\AirServer\AirServer.exe").VersionInfo.FileVersion

            # kürzt die Version auf 3 Zeichen
            if ($LocalVersion.Length -gt 5) {         
                $LocalVersion = $LocalVersion.Substring(0, 5)
            }
    
            Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
        } catch {
            Write-Log -Text " -Info: Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        }

        # Überprüft die aktuellste Version 
        try {
            $html = Invoke-WebRequest -Uri "https://www.filehorse.com/search?q=airserver" | Select-Object -ExpandProperty Content

            $pattern = '(?<=AirServer\s)(\d+\.\d+\.\d+)'
            $LatestVersion = [regex]::Match($html, $pattern).Value

            Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
               
        } catch {
            Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
        }

        

        # Überprüft ob AirServer aktualisiert werden muss
            if ($LocalVersion -ne $LatestVersion) {
                
                # Starten den Downlaod 
                try {
                    $url = "https://www.airserver.com/download/windows/classic/x64"

                    $folderPath = "C:\Program Files\APA\setups"

                    if (-not (Test-Path -Path $folderPath -PathType Container)) {
                        New-Item -ItemType Directory -Path $folderPath -Force
                        Write-Host "Folder created: $folderPath"
                    } 
                      
                    $destination = "$folderPath\AirServer-$LatestVersion.msi"
                    Invoke-WebRequest -Uri $url -OutFile $destination

                    Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"

                } catch {
                    Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
                } 

                # Startet die Installation 
                try {
                    Start-Process -FilePath $destination -ArgumentList "/q" -Wait
                    Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"

                } catch {
                    Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            
               }
            }

            # ÜBerprüft ob Lizenzschlüssel verfügbar ist 
            if ($false) {
            # if ("C:\Program Files\APA\config\script\AirServer.txt") {  

                try {
                    cd "C:\Program Files\App Dynamic\AirServer"
            
                    $validate = .\airserverconsole.exe validate

                    if ($validation -eq 0) {
                        Write-Host "AirServer ist aktiviert"

                    } else {

                        $licenseKey = Get-Content 'C:\Program Files\APA\config\script\AirServer.txt' -Raw

                        Write-Host "has"
                        Write-Host $licenseKey
                    
                        .\airserverconsole.exe activate $licenseKey

                        "$name wurde erfolgreich installiert"
                    }  
                }
                catch {
                    Write-Log -Text "Error: $($_.Exception.Message)" -ForegroundColor "red"
                    Write-Log -Text "Air Server wurde nicht Lizenziert" -ForegroundColor "red"
                }
            } else {
                Write-Log -Text "Kein Lizenzschlüssel hinterlegt"
            }
     
        } else {
        
            Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
        }
            Write-Host "Verarbeitung von $name abgeschloßen installiert."
            Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
            Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"

}

 
      
        

         

       
