﻿# function Update_audacity {

$name = "Audacity"

Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
Write-Host "Die Verarbeitung von $name wurde gestartet"
# Überprüft ob Audacity Installiert ist:

if (Test-Path "C:\Program Files\Audacity\Audacity.exe") {

    try {
        $LocalVersion = (Get-Item "C:\Program Files\Audacity\Audacity.exe" ).VersionInfo.ProductVersion
        Write-Log -Text " -Info $name ist in Version $Localversion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
     } catch {
        Write-Log -Text " -Error: Die Installierte Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
        Write-Host "Fehler aufgetreten: $_"
     }

     try {
        $html = Invoke-WebRequest -Uri "https://www.audacityteam.org" | Select-Object -ExpandProperty Content

     } catch {
        Write-Log -Text " -Error: Download von HTML-Code von $name zur ermittlung der Version ist fehlgeschlagen<br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
        Write-Host "Fehler aufgetreten: $_"
     }

    # Überprüft die aktuellste Version von Audacity 
    $html = Invoke-WebRequest -Uri "https://www.audacityteam.org" | Select-Object -ExpandProperty Content

    $pattern = 'Latest version : (\d+\.\d+\.\d+)'
    $regex = [regex]::new($pattern)

    $match = $regex.Match($html)
    if ($match.Success) {
        $LatestVersion = $match.Groups[1].Value

        # Ziffern der ersten Variable extrahieren
        $digits1 = $LocalVersion.split(',')

        # Ziffern der zweiten Variable extrahieren
        $digits2 = $LatestVersion.split('.')


        # Anzahl der Ziffern in beiden Variablen vergleichen
        if ($digits1.Count -lt $digits2.Count) {
            # Fehlende Ziffern in der ersten Variable hinzufügen
            $digits1 += ,('0' * ($digits2.Count - $digits1.Count))
        }
        elseif ($digits1.Count -gt $digits2.Count) {
            # Überflüssige Ziffern in der ersten Variable entfernen
            $digits1 = $digits1[0..($digits2.Count - 1)]
        }
    
        # Konvertierte Variable erstellen
        $LocalVersion = $digits1 -join '.'


        Write-Host ""
        Write-Host "Audacity ist auf diesem System in Version $LocalVersion installiert, die Aktuelle Version ist in $LatestVersion" 
        Write-Log -Text " -Info: Die Installierte Version von $name ist $LocalVersion <br>" -FilePath $LogFile -ForegroundColor "black"
        Write-Log -Text " -Info: Die Latest Version von $name ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
        
        # Überprüft ob Audacity aktualisiert werden muss
        if ($LocalVersion -ne $LatestVersion) {
            Write-Host "Die Aktualisierung von Audacity wurde gestartet" 

            $url = "https://github.com/audacity/audacity/releases/download/Audacity-$LatestVersion/audacity-win-$LatestVersion-x64.exe"

            $destination = "$env:USERPROFILE\Downloads\audacity-$LatestVersion.exe"

            try {
                Invoke-WebRequest -Uri $url -OutFile $destination
                Write-Log -Text " -Info: Setup von $name wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
            } catch {
               Write-Log -Text " Error: Setup von $name konnte nicht heruntergeladen werden <br>" -FilePath $LogFile -ForegroundColor "red"
            }

              try {
                Start-Process -FilePath $destination -ArgumentList /VERYSILENT  -Wait
                Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
            } catch {
                Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
                Write-Host "Ein Fehler ist aufgetreten: $_"
            }

        } else {
            Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "#000CD"
        }

    } else {
         Write-Log -Text " -Error: Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
    }

} else {
    Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "green"
}
    Write-Host "Verarbeitung von $name abgeschlossen installiert."
    Write-Log -Text " -Info: Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"

# }
