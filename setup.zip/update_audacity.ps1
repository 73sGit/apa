﻿function Update_audacity {
$PName = "Audacity"
Write-Host ""
# Überprüft ob Audacity Installiert ist:

if (Test-Path "C:\Program Files\Audacity\Audacity.exe") {

    $LocalVersion = (Get-Item "C:\Program Files\Audacity\Audacity.exe" ).VersionInfo.ProductVersion

    # Überprüft die aktuellste Version von Audacity 
    $html = Invoke-WebRequest -Uri "https://www.audacityteam.org" | Select-Object -ExpandProperty Content

    $pattern = 'Latest version : (\d+\.\d+\.\d+)'
    $regex = [regex]::new($pattern)

    $match = $regex.Match($html)
    if ($match.Success) {
        $LatestVersion = $match.Groups[1].Value

        # Ziffern der ersten Variable extrahieren
        $digits1 = $LocalVersion.split(',')

        # Ziffern der zweiten Variable extrahieren
        $digits2 = $LatestVersion.split('.')


        # Anzahl der Ziffern in beiden Variablen vergleichen
        if ($digits1.Count -lt $digits2.Count) {
            # Fehlende Ziffern in der ersten Variable hinzufügen
            $digits1 += ,('0' * ($digits2.Count - $digits1.Count))
        }
        elseif ($digits1.Count -gt $digits2.Count) {
            # Überflüssige Ziffern in der ersten Variable entfernen
            $digits1 = $digits1[0..($digits2.Count - 1)]
        }
    
        # Konvertierte Variable erstellen
        $LocalVersion = $digits1 -join '.'

        Write-Host ""
        Write-Host "Audacity ist auf diesem System in Version $LocalVersion installiert, die Aktuelle Version ist in $LatestVersion" 
        
        # Überprüft ob Audacity aktualisiert werden muss
        if ($LocalVersion -ne $LatestVersion) {
            Write-Host "Die Aktualisierung von Audacity wurde gestartet" 

            $url = "https://github.com/audacity/audacity/releases/download/Audacity-$LatestVersion/audacity-win-$LatestVersion-x64.exe"

            $destination = "$env:USERPROFILE\Downloads\audacity-$LatestVersion.exe"
            Invoke-WebRequest -Uri $url -OutFile $destination

            Write-Host "Der Download wurde gestartet" 

            Start-Process -FilePath $destination -ArgumentList /VERYSILENT  -Wait

            Write-Host "Die Installation von Audacity wurde erfolgreich abgeschlossen"
            Write-Host ""
        }

    } else {
        Write-Host "Latest Version not found."
    }

} else {
    Write-Host "Audacity ist auf diesem nicht System installiert" 
}

}
