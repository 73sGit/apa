﻿function Update_audacity {

$name = "Audacity"

Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
Write-Host "Die Verarbeitung von $name wurde gestartet"
# Überprüft ob Audacity Installiert ist:

if (Test-Path "C:\Program Files\Audacity\Audacity.exe") {
    
    try {
        $version = (Get-Item "C:\Program Files\Audacity\Audacity.exe" ).VersionInfo.ProductVersion
        $version = $version -replace ",", "."
        $Localversion = $version.TrimEnd('.0')
      
        Write-Log -Text " -Info $name ist in Version $Localversion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
     } catch {
        Write-Log -Text " -Error: Die Installierte Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
     }

     try {
        $html = Invoke-WebRequest -Uri "https://www.audacityteam.org" -UseBasicParsing | Select-Object -ExpandProperty Content

     } catch {
        Write-Log -Text " -Error: Download von HTML-Code von $name zur ermittlung der Version ist fehlgeschlagen<br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
        Write-Host "Fehler aufgetreten: $_"
     }

     $regexPattern = 'Download Audacity <!-- -->(\d+\.\d+\.\d+)'


    if ($html -match $regexPattern) {
        $LatestVersion = $matches[1]

        Write-Log -Text " -Info: Die aktuelle Version von $name ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
    } else {

        Write-Log -Text " -Error: Die aktuelle Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
    }

    # Überprüft ob Audacity aktualisiert werden muss
        if ($LocalVersion -ne $LatestVersion) {

            $url = "https://github.com/audacity/audacity/releases/download/Audacity-$LatestVersion/audacity-win-$LatestVersion-x64.exe"

            $destination = "c:\audacity-$LatestVersion.exe"

            try {
                Invoke-WebRequest -Uri $url -OutFile $destination
                Write-Log -Text " -Info: Setup von $name wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
            } catch {
               Write-Log -Text " -Error: Setup von $name konnte nicht heruntergeladen werden <br>" -FilePath $LogFile -ForegroundColor "red"
            }

              try {
                Start-Process -FilePath $destination -ArgumentList /VERYSILENT  -Wait
                Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
            } catch {
                Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
                Write-Host "Ein Fehler ist aufgetreten: $_"
            }

        } else {
            Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "green"
        }

} else {
    Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
}
    Write-Host "Verarbeitung von $name abgeschlossen installiert."
    Write-Log -Text " -Info: Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"

}
