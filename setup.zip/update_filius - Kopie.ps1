 # Ermittelt den Downlaod Link
             try {
                $html = Invoke-WebRequest -Uri "https://www.irfanview.com/" | Select-Object -ExpandProperty Content

                $pattern = 'www\.fosshub\.com/IrfanView[^"]+'
                $link = [regex]::Match($html, $pattern).Value

                $html = Invoke-WebRequest -Uri $link | Select-Object -ExpandProperty Content

                Write-Host $html

                $pattern = 'https://www.fosshub.com/IrfanView\.html\?dwl=iview466_x64_setup\.exe'
                $match = [regex]::Match($html, $pattern)

                if ($match.Success) {
                    $link = $match.Value
                    Write-Host "Gefundener Link: $link"
                } else {
                    Write-Host "Link nicht gefunden."
                }

               # Write-Log -Text " -Info: Ermmittlung des Links ist <br>" -FilePath $LogFile -ForegroundColor "green"

            } catch {
               #  Write-Log -Text " -Error: Ermmittlung des Links ist fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            } 