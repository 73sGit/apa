 # Ermittelt den Downlaod Link Part 1
             try {
                $html = Invoke-WebRequest -Uri "https://www.irfanview.com/" | Select-Object -ExpandProperty Content

                $pattern = 'www\.fosshub\.com/IrfanView[^"]+'
                $link = [regex]::Match($html, $pattern).Value

Write-Host "kdj"
                Write-Host $link

                Write-Log -Text $link + "<br>" -FilePath $LogFile -ForegroundColor "black"
                Write-Log -Text " -Info: Ermmittlung des Links 1 ist erfolgreich <br>" -FilePath $LogFile -ForegroundColor "green"

            } catch {
                Write-Log -Text " -Error: Ermmittlung des Links 1 ist fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            } 

             # Ermittelt den Downlaod Link Part 2
             try {
            

                # $html = Invoke-WebRequest -Uri $link | Select-Object -ExpandProperty Content

                # $pattern = 'https://www.fosshub.com/IrfanView\.html\?dwl=iview466_x64_setup\.exe'
                # $match = [regex]::Match($html, $pattern)

         
                   #  $link = $match.Value
                    # Write-Log "Gefundener Link: $link"
              

               #  Write-Log -Text " -Info: Ermmittlung des Links 2 ist erfolgreich" + "$link <br>" -FilePath $LogFile -ForegroundColor "green"

            } catch {
                # Write-Log -Text " -Error: Ermmittlung des Links 2 ist fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            } 