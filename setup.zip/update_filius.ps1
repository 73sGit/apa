function Update_filius {

$name = "Filius"
Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
Write-Host "Die Verarbeitung von $name wurde gestartet"

# �berpr�ft ob Filius Installiert ist
if (Test-Path "C:\Program Files\filius\filius.exe") {
    Write-Host "Filius ist installiert"

     # �berpr�ft die Installierte Version von Filius 
     try {
     
        $LocalVersion = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Filius").DisplayVersion
        Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
      
      
     } catch {
        Write-Log -Text " -Error: Die Installierte Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
     }

     
    # �berpr�ft die aktuellste Version 
     try {
       $html = Invoke-WebRequest -Uri "https://www.lernsoftware-filius.de/Herunterladen" | Select-Object -ExpandProperty Content

       $LatestVersion = [regex]::Match($html, '(?<=Filius-Setup_with-JRE-)\d+\.\d+').Value
       Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
               
    } catch {
        Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
    }

    # �berpr�fung, ob der String l�nger als 5 Zeichen ist
    if ($LocalVersion.Length -gt 3) {
        # Reduzierung des Strings auf 3 Zeichen
        $LocalVersion = $LocalVersion.Substring(0, 3)
    }
  
    # �berpr�ft ob Filius aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        $url = "https://www.lernsoftware-filius.de/downloads/Setup/Filius-Setup_with-JRE-$LatestVersion.1.exe"
          
        $folderPath = "C:\Program Files\APA\setups"

               if (-not (Test-Path -Path $folderPath -PathType Container)) {
                    New-Item -ItemType Directory -Path $folderPath -Force
                    Write-Host "Folder created: $folderPath"
                } 


        $destination = "$folderPath\filius-$LatestVersion.exe"

        # Startet den Downlaod 
        try {
            Invoke-WebRequest -Uri $url -OutFile $destination -UseBasicParsing
            Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
        } catch {
            Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            Write-Log -Text $_
        }

      # Startet die Installation 
       try {
            # Silent-Installation starten (auf deutsch)
            $installArguments = "/VERYSILENT /NORESTART /ALLUSER"

            Start-Process -FilePath $destination -ArgumentList "/S" -Wait
            Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"

        } catch {
            Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
        }   

       
        
    } else {
       Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "green"
   }
   
} else {
   Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"

}
Write-Host "Verarbeitung von $name abgeschlo�en installiert."
        Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"
 }