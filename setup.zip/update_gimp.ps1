# function Update_Gimp {
$name = "Gimp"
Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
Write-Host "Die Verarbeitung von $name wurde gestartet"

# �berpr�ft ob Gimp installiert ist, Welche Verison Gimp hat und wo es gespeichert ist

  
        $gimpKeyPath = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
        $gimpSubKey = Get-ItemProperty -Path $gimpKeyPath | Where-Object { $_.DisplayName -like 'GIMP*' }
      
      
   


# Falls Gimp installiert ist 
if ($gimpSubKey) {
    $installLocation = $gimpSubKey.InstallLocation
    $LocalVersion = $gimpSubKey.DisplayVersion
    # Write-Host "GIMP ist aktuell in Version: $GimpLocalVersion installiert"
    
    try {
        Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
      
      
     } catch {
        Write-Log -Text " -Error: Die Installierte Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
     }


    # �berpr�ft die aktuelle Version von Gimp 
  
     try {
        $html = Invoke-WebRequest "https://www.gimp.org/downloads/"
  
        # Crawlt den HTML Code by Element Id 
        $LatestVersion = $html.ParsedHtml.getElementById('win-download-link').innerText

        # K�rzt den String auf die Versionsnummer
        $string = "Download GIMP&nbsp;2.10.34<br/> directly"
        $LatestVersion = [regex]::Match($LatestVersion, "\d+\.\d+\.\d+").Value
        $LatestVersion = $LatestVersion

        # Write-Host "Die aktuellste Version von Gimp ist: " $LatestVersion
        Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
               
    } catch {
        Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
    }

  
  

    
 
    # �berpr�ft ob Gimp aktuell ist
   
    if($LocalVersion -ne $LatestVersion) {
        Write-Host "Aktualisierung von Gimp wird gestartet..."
        Write-Host 
 

        # Baut die Url zusammen
        $versionDigits = $LatestVersion.Split(".")
        $shortenedVersionDigits = $versionDigits[0..1]
        $shortenedVersion = $shortenedVersionDigits -join "."
        $url = "https://download.gimp.org/gimp/v$shortenedVersion/windows/gimp-" + $LatestVersion + "-setup.exe"

        $folderPath = "C:\Program Files\APA\setups"

               if (-not (Test-Path -Path $folderPath -PathType Container)) {
                    New-Item -ItemType Directory -Path $folderPath -Force
                    Write-Host "Folder created: $folderPath"
                } 


        $destination = "$folderPath\gimp-$LatestVersion-setup.exe"
        
        


        try {
            Invoke-WebRequest -Uri $url -OutFile $destination -UseBasicParsing
            Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
        } catch {
            Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
        }


        try {
            # Silent-Installation starten (auf deutsch)
            $installArguments = "/VERYSILENT /NORESTART /ALLUSER"

            Start-Process -FilePath $destination -ArgumentList $installArguments -Wait
            Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"

        } catch {
            Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
        }   



        
        # Write-Host "Bitte warten Sie bis Gimp aktualisiert wurde!"
        # Write-Host "Gimp wurde erfolgreich aktualisiert"

    } else {
        Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "green"
    }
    
} else {
    Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
}
  Write-Host "Verarbeitung von $name abgeschlo�en installiert."
        Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"
# }