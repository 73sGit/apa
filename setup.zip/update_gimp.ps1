function Update_Gimp {
$PName = "Gimp"
Write-Host ""
# �berpr�ft ob Gimp installiert ist, Welche Verison Gimp hat und wo es gespeichert ist
$gimpKeyPath = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
$gimpSubKey = Get-ItemProperty -Path $gimpKeyPath | Where-Object { $_.DisplayName -like 'GIMP*' }

# Falls Gimp installiert ist 
if ($gimpSubKey) {
    $installLocation = $gimpSubKey.InstallLocation
    $GimpLocalVersion = $gimpSubKey.DisplayVersion
    Write-Host "GIMP ist aktuell in Version: $GimpLocalVersion installiert"
    # Write-Host "Installationspfad: $installLocation"

    # �berpr�ft die aktuelle Version von Gimp 
    $WebResponse = Invoke-WebRequest "https://www.gimp.org/downloads/"
  
    # Crawlt den HTML Code by Element Id 
    $gimpCurrentVersion = $WebResponse.ParsedHtml.getElementById('win-download-link').innerText
  

    # K�rzt den String auf die Versionsnummer
    $string = "Download GIMP&nbsp;2.10.34<br/> directly"
    $gimpCurrentVersion = [regex]::Match($gimpCurrentVersion, "\d+\.\d+\.\d+").Value
    $gimpCurrentVersion = $gimpCurrentVersion

    Write-Host "Die aktuellste Version von Gimp ist: " $gimpCurrentVersion
 
    # �berpr�ft ob Gimp aktuell ist
   
    if($GimpLocalVersion -ne $gimpCurrentVersion) {
        Write-Host "Aktualisierung von Gimp wird gestartet..."
        Write-Host 
 

        # Baut die Url zusammen
        $versionDigits = $gimpCurrentVersion.Split(".")
        $shortenedVersionDigits = $versionDigits[0..1]
        $shortenedVersion = $shortenedVersionDigits -join "."
        $url = "https://download.gimp.org/gimp/v$shortenedVersion/windows/gimp-" + $gimpCurrentVersion + "-setup.exe"

        Write-Host $url
        $destination = "$env:USERPROFILE\Downloads\gimp-$gimpCurrentVersion-setup.exe"
        
        Invoke-WebRequest -Uri $url -OutFile $destination
        # Silent-Installation starten (auf deutsch)
        $installArguments = "/VERYSILENT /NORESTART /ALLUSER"
        Write-Host "Bitte warten Sie bis Gimp aktualisiert wurde!"
        Start-Process -FilePath $destination -ArgumentList $installArguments -Wait
        Write-Host "Gimp wurde erfolgreich aktualisiert"

    } else {
        Write-Host "Gimp ist bereits auf dem neusten Stand"
    }
    
} else {
    Write-Host "GIMP ist nicht installiert."
}


}