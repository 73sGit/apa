﻿function update_Inkscape {

    $name = "Inkscape"
     Write-Host "Die Verarbeitung von $name wurde gestartet"
     Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    
    # Überprüft ob Inkscape Installiert ist
    if (Test-Path "C:\Program Files\Inkscape\bin") {
    
        # Überprüft die Installierte Version von Inkscape
        try {
            $LocalVersion = (Get-Item "C:\Program Files\Inkscape\bin\inkscape.exe" ).VersionInfo.ProductVersion
    
            Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
        } catch {
            Write-Log -Text " -Info: Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        }
    
        # Überprüft die aktuellste Version 
        try {
            $html = Invoke-WebRequest -Uri "https://inkscape.org/release" | Select-Object -ExpandProperty Content
            
            $match = [regex]::Match($html, "<title>Download Inkscape (\d+\.\d+\.\d+) \| Inkscape</title>")
                
            $LatestVersion = $match.Groups[1].Value
    
            Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
                   
        } catch {
            Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
        }
    
    
        # Überprüft ob Inkscape aktualisiert werden muss
            if ($LocalVersion -ne $LatestVersion) {
                # Generiert die Url 
                $url = "https://inkscape.org/en/release/"
                $html = Invoke-WebRequest -Uri $url
    
                $version = [regex]::Match($html, '(?<=Inkscape\s)(\d+\.\d+\.\d+)').Value
    
                $url = "https://inkscape.org/release/inkscape-$version/windows/64-bit/msi/dl/"
                $html = Invoke-WebRequest -Uri $url
    
                $urlPattern = 'href="([^"]+/inkscape-1\.3\.2_[^"]+\.msi)"'

                $regexMatches = [regex]::Matches($html, $urlPattern)

                $url = $regexMatches.Groups[1].Value
               
       

                # https://inkscape.org/gallery/item/44619/inkscape-1.3.2_2023-11-25_091e20e-x64.msi

                
                # Startet den Download
                try {
                    $url = "https://inkscape.org" + $url

                    Write-Host "dskljfal"
                    Write-Host $url
    
                    $folderPath = "C:\Program Files\APA\setups"
    
                    if (-not (Test-Path -Path $folderPath -PathType Container)) {
                        New-Item -ItemType Directory -Path $folderPath -Force
                        Write-Host "Folder created: $folderPath"
                    } 
                          
                    $destination = "$folderPath\inkscape-$LatestVersion.msi"
                    Invoke-WebRequest -Uri $url -OutFile $destination
    
                    Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
    
                } catch {
                    Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
                } 
    
                # Startet die Installation 
                try {
                    Start-Process -FilePath $destination -ArgumentList "/qn" -Wait
                    Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
    
                } catch {
                    Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
               }
            }
       
    } else {
      
            Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
    }
    
    Write-Host "Verarbeitung von $name abgeschloßen installiert."
    Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"
}
    