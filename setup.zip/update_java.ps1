﻿function Update_Java {

    $name = "Java"

    Write-Host "Die Verarbeitung von $name wurde gestartet"
    Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"

    $ifInstalled = $false

    try {

        if (Test-Path -Path "C:\Program Files\Java\jre-1.8\bin" -PathType Container) {
            $javaVersionFilePath = "C:\Program Files\Java\jre-1.8\bin\java.exe"
            $ifInstalled = $true

        } elseif (Test-Path -Path "C:\Program Files\Java\jre1.8.0_361\bin\" -PathType Container) {
           $javaVersionFilePath = "C:\Program Files\Java\jre1.8.0_361\bin\java.exe"
           $ifInstalled = $true

        } else {
            $ifInstalled = $false
        }

    } catch {
        Write-Log -Text " -Error: Ermittlung ob $name installiert ist, ist nicht möglich <br>" -FilePath $LogFile -ForegroundColor "red"
    }  

    if ($ifInstalled -ne $false) {
        # Java-Version mithilfe von Get-Command und Select-Object abrufen
        $LocalVersion = (Get-Command $javaVersionFilePath).FileVersionInfo.FileVersion
        $LocalVersion = $LocalVersion.Substring(0, $LocalVersion.Length - 3)
        Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"

        # Überprüft die aktuelle Version von Java
        try {
            $html = Invoke-WebRequest -Uri "https://www.chip.de/downloads/Java-Runtime-Environment-64-Bit_42224883.html" -UseBasicParsing | Select-Object -ExpandProperty Content

            $regex = [regex]::new("Java Runtime Environment \(64 Bit\) (\d+\.\d+) Update (\d+)")
            $LatestVersion = $regex.Match($html).Groups[1].Value + "." + $regex.Match($html).Groups[2].Value  
    
            Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"  
        } catch {
            Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
        }

         # Überprüft ob Java aktuell ist
        if ($LocalVersion -ne $LatestVersion) {
        Write-Host "haser"
            try {
               $url = "https://javadl.oracle.com/webapps/download/AutoDL?BundleId=248774_8c876547113c4e4aab3c868e9e0ec572"
                $destination = "C:\java-$LatestVersion.exe"

                Invoke-WebRequest -Uri $url -OutFile $destination
    
                Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
                
                } catch {
                    Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
                }

                try {
                   $exePath = "C:\java-$LatestVersion.exe"

                    # Argumente für die stille Installation (kann je nach Installer variieren)
                    $installArgs = "/s"

                    # Überprüfen, ob die Datei existiert, bevor sie ausgeführt wird
                    if (Test-Path -Path $exePath -PathType Leaf) {
                        # Ausführung der Datei mit den angegebenen Argumenten
                        Start-Process -FilePath $exePath -ArgumentList $installArgs -Wait

                        Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"

                    } else {
                        Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen, da extPath not found <br>" -FilePath $LogFile -ForegroundColor "red"
                    }
    
          
                } catch {
                    Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
                }
            } else {
                Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "green"
            }
   
    } else {
        Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "black"
    }
        

        
        
      





        
    
       

        
     
    Write-Host "Verarbeitung von $name abgeschloßen."
    Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"


}
