﻿# function update_LibreOffice {
$PName = "LibreOffice"
Write-Host 
# Überprüft ob LibreOffice Installiert ist
if (Test-Path "C:\Program Files\LibreOffice\") {
    # Überprüft die installierte Version 
    $LocalVersion = (Get-Item "C:\Program Files\LibreOffice\program\scalc.exe" ).VersionInfo.ProductVersion
    Write-Host "$PName ist auf Ihrem System in Version $LocalVersion Installiert"

    # Überprüft die aktuellste Version von LibreOffice
    $html = Invoke-WebRequest -Uri "https://www.libreoffice.org/download/download-libreoffice/" | Select-Object -ExpandProperty Content
    $pattern = '(?<=LibreOffice\s)(\d+(\.\d+){1,2})'
    $LatestVersion = $html | Select-String -Pattern $pattern | ForEach-Object { $_.Matches.Value }
    Write-Host "Die neuste Version ist aktuell $LatestVersion"

     # Überprüft ob LibreOffice Aktualisiert werden muss
    if ($LocalVersion -ne $LatestVersion) {

        Write-Host "Der downlaod von $PName wurde gestartet..."
      
        $url = "https://download.documentfoundation.org/libreoffice/stable/" + $LatestVersion + "/win/x86_64/LibreOffice_" + $LatestVersion + "_Win_x86-64.msi"
       
        $destination = "$env:USERPROFILE\Downloads\LibreOffice-$LatestVersion.msi"
        
       
        
        # Invoke-WebRequest -Uri $url -OutFile $destination
        Write-Host "Die Installation von $PName wurde gestartet..."
            Start-Process -FilePath "msiexec" -ArgumentList "/i `"$destination`" /quiet" -Wait


        Write-Host "$PName Installation abgeschlossen"
        
    } else {
        echo "$PName ist bereits aktuell in Version $LatestVersion"
    }






} else {
    Write-Host "$PName ist auf Ihrem System nicht installiert!"
}
# }
