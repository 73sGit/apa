﻿function Update_netFramework {
 
    $name = ".NET-Framework"

    Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    Write-Host "Die Verarbeitung von $name wurde gestartet"

    # Überprüft in welcher Version .NET Framework Installiert ist:
    try {
        $LocalVersion = Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -Recurse | Get-ItemProperty -Name Version -ErrorAction SilentlyContinue | Where { $_.PSChildName -match '^(?!S)\p{L}'} | Select PSChildName, Version
        $LocalVersion = $LocalVersion[0].Version
        $LocalVersion = $LocalVersion.Substring(0,5)

        Write-Log -Text " -Info $name ist in Version $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
        Write-Host $LocalVersion    

    } catch {
        Write-Log -Text " -Error: Die Installierte Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
        Write-Host "Fehler aufgetreten: $_"    
    }

    # Überprüft die aktuellste Version von TeamViewer 
    try {
        $webClient = New-Object System.Net.WebClient
        $html = $webClient.DownloadString("https://learn.microsoft.com/en-us/dotnet/framework/migration-guide/versions-and-dependencies")

        $currentVersion = [regex]::Match($html, '\.NET Framework (\d+\.\d+\.\d+)').Groups[1].Value

        Write-Log -Text " -Info: Die aktuelle Version von $name ist $currentVersion <br>" -FilePath $LogFile -ForegroundColor "black"
        Write-Host "Version number: $currentVersion"

    } catch {
        Write-Log -Text " -Error: Download von HTML-Code von $name zur ermittlung der Version ist fehlgeschlagen<br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
        Write-Host "Fehler aufgetreten: $_"
    }

    if ($LocalVersion -eq "4.8.0") {
        $LocalVersion = "4.8.1"
    }


     if ($LocalVersion -ne $currentVersion) {
  	    # Startet Downlaod von .Net-Framework Setup
        try {
            $url = "https://go.microsoft.com/fwlink/?linkid=2203306"
            $destination = "C:\$name-$CurrentVersion.exe"

            Invoke-WebRequest -Uri $url -OutFile $destination 
            Write-Log -Text " -Info: Setup von $name wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
            Write-Host $name "wurde heruntergeladen" 

        } catch {
            Write-Log -Text " -Error: Setup von $name konnte nicht heruntergeladen werden <br>" -FilePath $LogFile -ForegroundColor "red"
            Write-Log "Ein Fehler ist aufgetreten: $_"
            Write-Host "Fehler aufgetreten: $_"
        }

        # Startet Installation von .NET-Framework
        try {
            Write-Host "Update start"
            Start-Process -FilePath $destination -ArgumentList "/q /norestart" -Wait
            Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
            Write-Host "Install end"
        } catch {
            Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
            Write-Host "Ein Fehler ist aufgetreten: $_"
        }

    } else {
        Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "green"
        Write-Host "Aktaulisierutn nicht notwenig"
    }
}
