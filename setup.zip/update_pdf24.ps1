﻿function update_pdf24 {
    $name = "PDF24"
    Write-Host "Die Verarbeitung von $name wurde gestartet"
    Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"

    # Überprüft ob PDF24 Installiert ist
    if (Test-Path "C:\Program Files\PDF24\pdf24.exe") {

        # Überprüft die Installierte Version 
        try {
            $LocalVersion = (Get-Item "C:\Program Files\PDF24\pdf24.exe" ).VersionInfo.ProductVersion 

            Write-Log -Text " -Info: $name ist in Version: $LocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
        } catch {
            Write-Log -Text " -Info: Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        }

        # Überprüft die aktuellste Version 
        try {
            $html = Invoke-WebRequest -Uri "https://www.pdf24.org/de/" | Select-Object -ExpandProperty Content

            # Extrahiert die Version aus dem html Code
            $pattern = '(?<=<span>PDF24 Creator<\/span>\s+)<span>(\d+\.\d+\.\d+)<\/span>'
            $LatestVersion = [regex]::Match($html, $pattern).Groups[1].Value

             Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"
        } catch {
            Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
        }

        # Überprüft ob PDF24 aktualisiert werden muss
        if ($LocalVersion -ne $LatestVersion) {

            # Startet den Download 
            try {
                $url = "https://download.pdf24.org/pdf24-creator-11.15.2-x64.exe"

                $destination = "C:\Program Files\APA\setups\pdf24-$LatestVersion.exe"
                $argumente = "/VERYSILENT /NORESTART"
                Invoke-WebRequest -Uri $url -OutFile $destination

                Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
            } catch {
                Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
            }

            # Startet die Installation 
            try {
                Start-Process -FilePath $destination -ArgumentList $argumente -Verb RunAs -PassThru

                Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
            } catch {
                Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
            }

        } else {
            Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "green"
        }
    } else {
        
        Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
    }
        Write-Host "Verarbeitung von $name abgeschloßen installiert."
        Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"

}
