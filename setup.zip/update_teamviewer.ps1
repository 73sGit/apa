﻿function Update_TeamViewer {
 
$name = "TeamViewer"

Write-Log -Text "$Timestamp -Info: Aktualisierung von $name gestartet <br>" -FilePath $LogFile -ForegroundColor "red"
Write-Host "Die Verarbeitung von $name wurde gestartet"

# Überprüft ob TeamViewer Installiert ist:

if (Test-Path "C:\Program Files (x86)\TeamViewer\TeamViewer.exe") {
    
    $LocalVersion = (Get-Item "C:\Program Files (x86)\TeamViewer\TeamViewer.exe" ).VersionInfo.ProductVersion

    # Überprüft die aktuellste Version von TeamViewer 
    try {
        $html = Invoke-WebRequest -Uri "https://www.teamviewer.com/de/download/windows/" | Select-Object -ExpandProperty Content -UseBasicParsing
        Write-Log -Text "$Timestamp -Info: Download - $name-HTML erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
    } catch {
        Write-Log -Text "$Timestamp -Error: Download - $name-HTML wurde nicht erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
    }
    
    
    # Extrahiert die Version aus dem HTML Code
    $pattern = 'Aktuelle Version: <span data-dl-version-label>(.*?)<\/span>'
    $matches = [regex]::Match($html, $pattern)

    # Überprüft ob das Extrahieren erfolgreich war
    if ($matches.Success) {
        $currentVersion = $matches.Groups[1].Value
        Write-Log -Text "$Timestamp -Info: Version von $name ist $currentVersion <br>" -FilePath $LogFile -ForegroundColor "black"
    } else {
        Write-Log -Text "$Timestamp -Error: Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
    }

    # Kürzt die Verison
    $LocalVersion = ($LocalVersion  -split '\.')[0..2] -join '.'

    # Überprüft ob Update erforderlich
    if ($LocalVersion -ne $currentVersion) {

        $url = "https://download.teamviewer.com/download/TeamViewer_Host_Setup.exe"
        $destination = "$env:USERPROFILE\Downloads\TeamViewer-$CurrentVersion.exe"

        try {
            Invoke-WebRequest -Uri $url -OutFile $destination -UseBasicParsing
            Write-Log -Text "$Timestamp -Info: Download - $name-Setup erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
        } catch {
            Write-Log -Text "$Timestamp -Error: Download - $name-Setup erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
        }

         try {
            Start-Process -FilePath $destination -ArgumentList "/S" -Wait
            Write-Log -Text "$Timestamp -Info: Aktualisierung von $name abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
        } catch {
            Write-Log -Text "$Timestamp -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
        }
 
    } else {
        Write-Log -Text "$Timestamp -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "black"
    }

    
} else {
        
        Write-Log -Text "$Timestamp -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "green"
    }
        Write-Host "Verarbeitung von $name abgeschlossen installiert."
        Write-Log -Text "$Timestamp -Info: Überprüfung und Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "green"
}
