﻿function Update_TeamViewer {
 
$name = "TeamViewer"

Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
Write-Host "Die Verarbeitung von $name wurde gestartet"

# Überprüft ob TeamViewer Installiert ist:

if (Test-Path "C:\Program Files (x86)\TeamViewer\TeamViewer.exe") {
    
    try {
        $LocalVersion = (Get-Item "C:\Program Files (x86)\TeamViewer\TeamViewer.exe" ).VersionInfo.ProductVersion
        Write-Log -Text " -Info $name ist in Version $Localversion installiert <br>" -FilePath $LogFile -ForegroundColor "black"
     } catch {
        Write-Log -Text " -Error: Die Installierte Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
        Write-Host "Fehler aufgetreten: $_"
     }

    # Überprüft die aktuellste Version von TeamViewer 
     try {
        $webClient = New-Object System.Net.WebClient
        $html = $webClient.DownloadString("https://www.teamviewer.com/de/download/windows/")

     } catch {
        Write-Log -Text " -Error: Download von HTML-Code von $name zur ermittlung der Version ist fehlgeschlagen<br>" -FilePath $LogFile -ForegroundColor "red"
        Write-Log -Text " -Error: $_" -FilePath $LogFile -ForegroundColor "red"
        Write-Host "Fehler aufgetreten: $_"
     }
    
    # Extrahiert die Version aus dem HTML Code
    $pattern = 'Aktuelle Version: <span data-dl-version-label>(.*?)<\/span>'
    $matches = [regex]::Match($html, $pattern)

    # Überprüft ob das Extrahieren erfolgreich war
    if ($matches.Success) {
        $currentVersion = $matches.Groups[1].Value
        Write-Log -Text " -Info: Die aktuelle Version von $name ist $currentVersion <br>" -FilePath $LogFile -ForegroundColor "black"
    } else {
        Write-Log -Text " -Error: Version von $name konnte nicht ermittelt werden <br>" -FilePath $LogFile -ForegroundColor "red"
    }

    # Kürzt die Verison
    $LocalVersion = ($LocalVersion  -split '\.')[0..2] -join '.'
   
    # Überprüft ob Update erforderlich
    if ($LocalVersion -ne $currentVersion) {

        $url = "https://download.teamviewer.com/download/TeamViewer_Host_Setup.exe"
        $destination = "C:\TeamViewer-$CurrentVersion.exe"

        try {
            Invoke-WebRequest -Uri $url -OutFile $destination 
            Write-Log -Text " -Info: Setup von $name wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
        } catch {
            try {
                $url = "https://dlgbit.winfuture.de/QSwfcBdPMy8mEyqOPZsojg/1697154265/3005/software/teamviewer/$CurrentVersion/TeamViewer_Setup.exe"
                Invoke-WebRequest -Uri $url -OutFile $destination 
                Write-Log -Text " -Info: Setup von $name wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
            } catch {
                Write-Log -Text " -Error: Setup von $name konnte nicht heruntergeladen werden <br>" -FilePath $LogFile -ForegroundColor "red"
                Write-Log "Ein Fehler ist aufgetreten: $_"
            }
        }

         try {

            Start-Process -FilePath $destination -ArgumentList "/S" -Wait
            Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
        } catch {
            Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
            Write-Host "Ein Fehler ist aufgetreten: $_"
        }
 
    } else {
        Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    }

    
} else {
        
        Write-Log -Text " -Info: Aktualisierung nicht notwendig, da nicht installiert <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    }
        Write-Host "Verarbeitung von $name abgeschlossen installiert."
        Write-Log -Text " -Info: Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"
}
