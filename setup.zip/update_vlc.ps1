function Update_VLC {
    $name = "VLC-Media Player"

    Write-Host "Die Verarbeitung von $name wurde gestartet"
    Write-Log -Text "$Timestamp -Info: Aktualisierung von $name gestartet <br>" -FilePath $LogFile -ForegroundColor "red"
    $vlcInstallationsPfad = Get-ItemProperty -Path "HKLM:\Software\VideoLAN\VLC" -Name "InstallDir" -ErrorAction SilentlyContinue

    # �berpr�ft ob VLC Media Player installiert ist
    if ($vlcInstallationsPfad -ne $null) {
        $vlcAusf�hrbarerPfad = Join-Path -Path $vlcInstallationsPfad.InstallDir -ChildPath "vlc.exe"
        # �berpr�ft die lokale VLC Media Player Version 
        if (Test-Path $vlcAusf�hrbarerPfad) {
            $versionInfo = (Get-Item $vlcAusf�hrbarerPfad).VersionInfo
            $vlcLocalVersion = $versionInfo.FileVersion
           
            Write-Log -Text "$Timestamp -Info: Version - Installiert: $vlcLocalVersion <br>" -FilePath $LogFile -ForegroundColor "black"

            # �berpr�ft die aktuelle VLC Media Player Version 
            try {
                $html = Invoke-WebRequest "https://www.videolan.org/vlc/" -UseBasicParsing
                Write-Log -Text "$Timestamp -Info: Download - VLC-HTML erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
            } catch {
                Write-Log -Text "$Timestamp -Error: Download - VLC-HTML erfolgreich erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
            }
            
            $LatestVersion = [regex]::Match($html, '(?<=<span id=''downloadVersion''>\s*)[\d.]+').Value

            Write-Log -Text "$Timestamp -Info: Version - Current: $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"

            # Entferne Leerzeichen aus der Version
            $LatestVersion = $LatestVersion.Trim()

            # �berpr�ft ob die locale Version aktuell ist   
            if ($vlcLocalVersion -ne $LatestVersion) {
                # Startet den Download von VLC-Media Player
                
    
                $url = "https://ftp.halifax.rwth-aachen.de/videolan/vlc/$LatestVersion/win64/vlc-$LatestVersion-win64.exe"
                      
                $destination = "$env:USERPROFILE\Downloads\vlc-$LatestVersion-win64.exe"

                 try {
                    Invoke-WebRequest -Uri $url -OutFile $destination -UseBasicParsing
                    Write-Log -Text "$Timestamp -Info: Download - VLC-Setup erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
                } catch {
                    Write-Log -Text "$Timestamp -Error: Download - VLC-Setup erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
                }

                # Silent-Installation starten (auf deutsch)
                $installArguments = "/L=1031 /S"
                try {
                    Start-Process -FilePath $destination -ArgumentList $installArguments -Wait
                    Write-Log -Text "$Timestamp -Info: Aktualisierung von $name abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
                } catch {
                    Write-Log -Text "$Timestamp -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
                }                
                
            }
            Write-Log -Text "$Timestamp -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "black"
        }
    } else {
        
        Write-Log -Text "$Timestamp -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "green"
    }
        Write-Host "Verarbeitung von $name abgeschlo�en installiert."
        Write-Log -Text "$Timestamp -Info: �berpr�fung und Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "green"
}