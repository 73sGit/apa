function Update_VLC {
    $vlcInstallationsPfad = Get-ItemProperty -Path "HKLM:\Software\VideoLAN\VLC" -Name "InstallDir" -ErrorAction SilentlyContinue

    # �berpr�ft ob VLC Media Player installiert ist
    if ($vlcInstallationsPfad -ne $null) {
        $vlcAusf�hrbarerPfad = Join-Path -Path $vlcInstallationsPfad.InstallDir -ChildPath "vlc.exe"
        # �berpr�ft die lokale VLC Media Player Version 
        if (Test-Path $vlcAusf�hrbarerPfad) {
            $versionInfo = (Get-Item $vlcAusf�hrbarerPfad).VersionInfo
            $vlcLocalVersion = $versionInfo.FileVersion
            Write-Host "VLC ist auf diesem Computer installiert. Version: $vlcLocalVersion"

            # �berpr�ft die aktuelle VLC Media Player Version 
            $WebResponse = Invoke-WebRequest "https://www.videolan.org/vlc/"
            $vlcCurrentVersion = $WebResponse.ParsedHtml.getElementById('downloadVersion').innerText
            Write-Host "Die aktuelle VLC-Media Player Version ist: " $vlcCurrentVersion
   
            # Entferne Leerzeichen aus der Version
            $vlcCurrentVersion = $vlcCurrentVersion.Trim()

            # �berpr�ft ob die locale Version aktuell ist   
            if ($vlcLocalVersion -ne $vlcCurrentVersion) {
                # Startet den Download von VLC-Media Player
                Write-Host "VLC Update gestartet"
    
                $url = "https://ftp.halifax.rwth-aachen.de/videolan/vlc/$vlcCurrentVersion/win64/vlc-$vlcCurrentVersion-win64.exe"

                Write-Host $url
                $destination = "$env:USERPROFILE\Downloads\vlc-$vlcCurrentVersion-win64.exe"

                Invoke-WebRequest -Uri $url -OutFile $destination

                # Silent-Installation starten (auf deutsch)
                $installArguments = "/L=1031 /S"
                Start-Process -FilePath $destination -ArgumentList $installArguments -Wait

                Write-Host "Die Installation von VLC-Media Player wurde erfolgreich abgeschlossen!"
            }



        } else {
            Write-Host "VLC-Datei nicht gefunden."
        }
    } else {
        Write-Host "VLC ist auf diesem Computer nicht installiert."
    }
}