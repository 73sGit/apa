function Update_VLC {
    $name = "VLC-Media Player"

    Write-Log -Text "$Timestamp -Info: Aktualisierung von $name gestartet <br>" -FilePath $LogFile -ForegroundColor "red"
    $vlcInstallationsPfad = Get-ItemProperty -Path "HKLM:\Software\VideoLAN\VLC" -Name "InstallDir" -ErrorAction SilentlyContinue

    # �berpr�ft ob VLC Media Player installiert ist
    if ($vlcInstallationsPfad -ne $null) {
        $vlcAusf�hrbarerPfad = Join-Path -Path $vlcInstallationsPfad.InstallDir -ChildPath "vlc.exe"
        # �berpr�ft die lokale VLC Media Player Version 
        if (Test-Path $vlcAusf�hrbarerPfad) {
            $versionInfo = (Get-Item $vlcAusf�hrbarerPfad).VersionInfo
            $vlcLocalVersion = $versionInfo.FileVersion
            Write-Host "$name ist auf diesem Computer installiert. Version: $vlcLocalVersion"
            Write-Log -Text "$Timestamp -Info: Version - Installiert: $vlcLocalVersion <br>" -FilePath $LogFile -ForegroundColor "black"

            # �berpr�ft die aktuelle VLC Media Player Version 
            $html = Invoke-WebRequest "https://www.videolan.org/vlc/"
            $LatestVersion = [regex]::Match($html, '(?<=<span id=''downloadVersion''>\s*)[\d.]+').Value

        
            Write-Host "Die aktuelle VLC-Media Player Version ist: " $LatestVersion
            Write-Log -Text "$Timestamp -Info: Version - Current: $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"

            # Entferne Leerzeichen aus der Version
            $LatestVersion = $LatestVersion.Trim()

            # �berpr�ft ob die locale Version aktuell ist   
            if ($vlcLocalVersion -ne $LatestVersion) {
                # Startet den Download von VLC-Media Player
                Write-Host "VLC Update gestartet"
    
                $url = "https://ftp.halifax.rwth-aachen.de/videolan/vlc/$LatestVersion/win64/vlc-$LatestVersion-win64.exe"
            

                Write-Host $url
                $destination = "$env:USERPROFILE\Downloads\vlc-$LatestVersion-win64.exe"

                Invoke-WebRequest -Uri $url -OutFile $destination

                # Silent-Installation starten (auf deutsch)
                $installArguments = "/L=1031 /S"
                Start-Process -FilePath $destination -ArgumentList $installArguments -Wait

                Write-Host "Die Installation von $name wurde erfolgreich abgeschlossen!"
                Write-Log -Text "$Timestamp -Info: Aktualisierung von $name abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "black"
            }

        } else {
            Write-Host "VLC-Datei nicht gefunden."
            Write-Log -Text "$Timestamp -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "black"
        }
    } else {
        Write-Host "$name ist auf diesem Computer nicht installiert."
        Write-Log -Text "$Timestamp -Info: �berpr�fung und Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
        Write-Log -Text "<br><br>" -FilePath $LogFile -ForegroundColor "green"
    }
        Write-Log -Text "$Timestamp -Info: �berpr�fung und Aktualisierung von 7-Zip wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "green"
}