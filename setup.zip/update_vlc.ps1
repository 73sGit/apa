function Update_VLC {
    $name = "VLC-Media Player"

    Write-Host "Die Verarbeitung von $name wurde gestartet"
    Write-Log -Text " -Info: Verarbeitung von $name wurde gestartet <br>" -FilePath $LogFile -ForegroundColor "#000CD"
    $vlcInstallationsPfad = Get-ItemProperty -Path "HKLM:\Software\VideoLAN\VLC" -Name "InstallDir" -ErrorAction SilentlyContinue

    # �berpr�ft ob VLC Media Player installiert ist
    if ($vlcInstallationsPfad -ne $null) {
        $vlcAusf�hrbarerPfad = Join-Path -Path $vlcInstallationsPfad.InstallDir -ChildPath "vlc.exe"
        # �berpr�ft die lokale VLC Media Player Version 
        if (Test-Path $vlcAusf�hrbarerPfad) {
            $versionInfo = (Get-Item $vlcAusf�hrbarerPfad).VersionInfo
            $vlcLocalVersion = $versionInfo.FileVersion
           
            Write-Log -Text " -Info: $name ist in Version: $vlcLocalVersion installiert <br>" -FilePath $LogFile -ForegroundColor "black"

            # �berpr�ft die aktuelle VLC Media Player Version 
            try {
                $html = Invoke-WebRequest "https://www.videolan.org/vlc/" -UseBasicParsing
               
            } catch {
                Write-Log -Text " -Error: Download - HTML-Code zur Ermittlung der Version fehlgeschlagen <br>" -FilePath $LogFile -ForegroundColor "red"
            }
            
            $LatestVersion = [regex]::Match($html, '(?<=<span id=''downloadVersion''>\s*)[\d.]+').Value

            Write-Log -Text " -Info: Die aktuelle Version ist $LatestVersion <br>" -FilePath $LogFile -ForegroundColor "black"

            # Entferne Leerzeichen aus der Version
            $LatestVersion = $LatestVersion.Trim()

            # �berpr�ft ob die locale Version aktuell ist   
            if ($vlcLocalVersion -ne $LatestVersion) {
                # Startet den Download von VLC-Media Player
                
    
                $url = "https://ftp.halifax.rwth-aachen.de/videolan/vlc/$LatestVersion/win64/vlc-$LatestVersion-win64.exe"
                      
                $destination = "C:\vlc-$LatestVersion.exe"

                 try {
                    Invoke-WebRequest -Uri $url -OutFile $destination -UseBasicParsing
                    Write-Log -Text " -Info: Setup von $name Setup wurde erfolgreich heruntergeladen <br>" -FilePath $LogFile -ForegroundColor "green"
                } catch {
                    Write-Log -Text " -Error: Download von $name Setup fehlgeschlagen  <br>" -FilePath $LogFile -ForegroundColor "red"
                }

                # Silent-Installation starten (auf deutsch)
                $installArguments = "/L=1031 /S"
                try {
                    Start-Process -FilePath $destination -ArgumentList $installArguments -Wait
                    Write-Log -Text " -Info: Aktualisierung von $name wurde erfolgreich abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "green"
                } catch {
                    Write-Log -Text " -Error: Aktualisierung von $name wurde nicht abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "red"
                }                
                
            } else {
                Write-Log -Text " -Info: Aktualisierung nicht notwendig, da bereits aktuell <br>" -FilePath $LogFile -ForegroundColor "green"
            }
        }
    } else {
        
        Write-Log -Text " -Info: $name ist auf diesem System nicht installiert <br>" -FilePath $LogFile -ForegroundColor "green"
    }
        Write-Host "Verarbeitung von $name abgeschlo�en installiert."
        Write-Log -Text " -Info: Die Verarbeitung von $name wurde abgeschlossen <br>" -FilePath $LogFile -ForegroundColor "#000CD"
        Write-Log -Text "<br>" -FilePath $LogFile -ForegroundColor "black"
}