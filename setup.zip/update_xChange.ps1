﻿ function update_xchange {
 
Write-Host 
$PName = "PDF XChange"
# Überprüft ob PDF XChange Installiert ist:
$path = "C:\Program Files\Tracker Software\PDF Editor\PDFXEdit.exe"

if (Test-Path $path) {

    $LocalVersion = (Get-Item "$path" ).VersionInfo.ProductVersion
   
    Write-Host "Die Installierte Version von $PName ist $LocalVersion"

    # Überprüft die aktuellste Version von PDF XChange 
    $html = Invoke-WebRequest -Uri "https://www.tracker-software.com/product/downloads"
    $LatestVersion = $html.ParsedHtml.getElementsByClassName("versionname") | Select-Object -First 1 -ExpandProperty innerText


    Write-Host "Die aktuelle Version von $PName ist: $LatestVersion"

    
    # Prüft ob ein Update erforderlich ist
    if ($LocalVersion -ne $LatestVersion) {

        # Startet die Installation von PDF-XChange
        Write-Host "Die Aktualisierung von $PName wurde gestartet!"

        # Deinstalliert Version 9
        $filePath = "C:\ProgramData\Package Cache\{dfe99c19-edbd-4d93-ae19-76f8b67e3e00}\PDFXVE9.exe"
        $arguments = "/uninstall /S"

        Start-Process -FilePath $filePath -ArgumentList $arguments -Wait

        # Startet Installation
        $url = "https://www.tracker-software.com/downloads/EditorV10.x64.msi?key=kXCIPmivx9/dUa2fMJMPtAsbRzH2NLNvuYBvWfgmyuHDdMOL%2BQDrXyjv18DrjHkl"
        $Destination = "$env:USERPROFILE\Downloads\$PName-$LatestVersion.msi"
        Invoke-WebRequest -Uri $url -OutFile $destination

        Start-Process -FilePath $destination -ArgumentList "/quiet" -Wait

        Write-Host "Die Aktualisierung von $PName wurde erfolgreich abgeschlossen"


        } else {
        Write-Host "$PName ist auf dem neusten Stand, keine Aktalisierung verfügbar!"
        }
} else {
    Write-Host "$PName ist nicht auf diesem System installiert!"
}


}
